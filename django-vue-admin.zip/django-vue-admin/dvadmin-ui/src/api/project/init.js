import request from '@/utils/request'

// 查询参数列表
export function listInitParam(query) {
  return request({
    url: '/project/InitParam/',
    method: 'get',
    params: query
  })
}

// 新增参数
export function addInitParam(data) {
  return request({
    url: '/project/InitParam/',
    method: 'post',
    data: data
  })
}
