import request from '@/utils/request'

export function importHostDeviceTemplate() {
  return request({
    url: '/project/HostDevice/importTemplate/',
    method: 'get'
  })
}

export function importHostDevice(data) {
  return request({
    url: '/project/HostDevice/importTemplate/',
    method: 'post',
    data: data
  })
}

export function listHostDevice(query) {
  return request({
    url: '/project/HostDevice/',
    method: 'get',
    params: query
  })
}

export function cleanHostDevice() {
  return request({
    url: '/project/HostDevice/clean/',
    method: 'get'
  })
}

export function delHostDevice(id) {
  return request({
    url: '/project/HostDevice/' + id + '/',
    method: 'delete'
  })
}

export function importAircooledHeatpumpUnitTemplate() {
  return request({
    url: '/project/AircooledHeatpumpUnit/importTemplate/',
    method: 'get'
  })
}

export function importAircooledHeatpumpUnit(data) {
  return request({
    url: '/project/AircooledHeatpumpUnit/importTemplate/',
    method: 'post',
    data: data
  })
}

export function listAircooledHeatpumpUnit(query) {
  return request({
    url: '/project/AircooledHeatpumpUnit/',
    method: 'get',
    params: query
  })
}

export function cleanAircooledHeatpumpUnit() {
  return request({
    url: '/project/AircooledHeatpumpUnit/clean/',
    method: 'get'
  })
}

export function delAircooledHeatpumpUnit(id) {
  return request({
    url: '/project/AircooledHeatpumpUnit/' + id + '/',
    method: 'delete'
  })
}

export function importEvaporativeCoolingMachineTemplate() {
  return request({
    url: '/project/EvaporativeCoolingMachine/importTemplate/',
    method: 'get'
  })
}

export function importEvaporativeCoolingMachine(data) {
  return request({
    url: '/project/EvaporativeCoolingMachine/importTemplate/',
    method: 'post',
    data: data
  })
}

export function listEvaporativeCoolingMachine(query) {
  return request({
    url: '/project/EvaporativeCoolingMachine/',
    method: 'get',
    params: query
  })
}

export function cleanEvaporativeCoolingMachine() {
  return request({
    url: '/project/EvaporativeCoolingMachine/clean/',
    method: 'get'
  })
}

export function delEvaporativeCoolingMachine(id) {
  return request({
    url: '/project/EvaporativeCoolingMachine/' + id + '/',
    method: 'delete'
  })
}

export function importCoolingTowerTemplate() {
  return request({
    url: '/project/CoolingTower/importTemplate/',
    method: 'get'
  })
}

export function importCoolingTower(data) {
  return request({
    url: '/project/CoolingTower/importTemplate/',
    method: 'post',
    data: data
  })
}

export function listCoolingTower(query) {
  return request({
    url: '/project/CoolingTower/',
    method: 'get',
    params: query
  })
}

export function cleanCoolingTower() {
  return request({
    url: '/project/CoolingTower/clean/',
    method: 'get'
  })
}

export function delCoolingTower(id) {
  return request({
    url: '/project/CoolingTower/' + id + '/',
    method: 'delete'
  })
}

export function importLoadDrywetbulbtemperatureTemplate() {
  return request({
    url: '/project/LoadDrywetbulbtemperature/importTemplate/',
    method: 'get'
  })
}

export function importLoadDrywetbulbtemperature(data) {
  return request({
    url: '/project/LoadDrywetbulbtemperature/importTemplate/',
    method: 'post',
    data: data
  })
}

export function listLoadDrywetbulbtemperature(query) {
  return request({
    url: '/project/LoadDrywetbulbtemperature/',
    method: 'get',
    params: query
  })
}

export function cleanLoadDrywetbulbtemperature() {
  return request({
    url: '/project/LoadDrywetbulbtemperature/clean/',
    method: 'get'
  })
}

export function delLoadDrywetbulbtemperature(id) {
  return request({
    url: '/project/LoadDrywetbulbtemperature/' + id + '/',
    method: 'delete'
  })
}

export function importCoolingWaterPumpTemplate() {
  return request({
    url: '/project/CoolingWaterPump/importTemplate/',
    method: 'get'
  })
}

export function importCoolingWaterPump(data) {
  return request({
    url: '/project/CoolingWaterPump/importTemplate/',
    method: 'post',
    data: data
  })
}

export function listCoolingWaterPump(query) {
  return request({
    url: '/project/CoolingWaterPump/',
    method: 'get',
    params: query
  })
}

export function cleanCoolingWaterPump() {
  return request({
    url: '/project/CoolingWaterPump/clean/',
    method: 'get'
  })
}

export function delCoolingWaterPump(id) {
  return request({
    url: '/project/CoolingWaterPump/' + id + '/',
    method: 'delete'
  })
}

export function importChilledWaterPumpTemplate() {
  return request({
    url: '/project/ChilledWaterPump/importTemplate/',
    method: 'get'
  })
}

export function importChilledWaterPump(data) {
  return request({
    url: '/project/ChilledWaterPump/importTemplate/',
    method: 'post',
    data: data
  })
}

export function listChilledWaterPump(query) {
  return request({
    url: '/project/ChilledWaterPump/',
    method: 'get',
    params: query
  })
}

export function cleanChilledWaterPump() {
  return request({
    url: '/project/ChilledWaterPump/clean/',
    method: 'get'
  })
}

export function delChilledWaterPump(id) {
  return request({
    url: '/project/ChilledWaterPump/' + id + '/',
    method: 'delete'
  })
}
