<template style="background: blue">
  <div class="fit" >
    <el-form ref="form" :model="form" >
      <el-tabs v-model="activeName" @tab-click="handleClick" style="margin:10px">
        <el-tab-pane label="数据拟合" name="first" style="height:683px">
          <el-card class="box-card" style="margin: 10px;margin-left: 10px;margin-top: 0px;;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >蒸发冷一体机组系数（制热工况）</span>
              <i class="el-icon-bangzhu"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >L0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L0"></span></el-col>
              <el-col :span="1" ><span >L1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.L1"></span></el-col>
              <el-col :span="1"><span >L2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L2"></span></el-col>
              <el-col :span="1"><span >L3</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L3"></span></el-col>
              <el-col :span="1"><span >L4</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L4"></span></el-col>
              <el-col :span="1"><span >L5</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L5"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >L6</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L6"></span></el-col>
              <el-col :span="1" ><span >L7</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.L7"></span></el-col>
              <el-col :span="1"><span >L8</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L8"></span></el-col>
              <el-col :span="1"><span >L9</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.L9"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE5"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE5"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-left: 620px;margin-top: 0px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >风冷热泵机组系数（制热工况）</span>
              <i class="el-icon-bangzhu"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >J0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J0"></span></el-col>
              <el-col :span="1" ><span >J1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.J1"></span></el-col>
              <el-col :span="1"><span >J2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J2"></span></el-col>
              <el-col :span="1"><span >J3</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J3"></span></el-col>
              <el-col :span="1"><span >J4</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J4"></span></el-col>
              <el-col :span="1"><span >J5</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J5"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >J6</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J6"></span></el-col>
              <el-col :span="1" ><span >J7</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.J7"></span></el-col>
              <el-col :span="1"><span >J8</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J8"></span></el-col>
              <el-col :span="1"><span >J9</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.J9"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE3"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE3"></span></el-col>
              <el-col :span="4"></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 162px;margin-left: 10px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >风冷热泵机组系数（制冷工况）</span>
              <i class="el-icon-bangzhu"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >F0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F0"></span></el-col>
              <el-col :span="1" ><span >F1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.F1"></span></el-col>
              <el-col :span="1"><span >F2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F2"></span></el-col>
              <el-col :span="1"><span >F3</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F3"></span></el-col>
              <el-col :span="1"><span >F4</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F4"></span></el-col>
              <el-col :span="1"><span >F5</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F5"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >F6</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F6"></span></el-col>
              <el-col :span="1" ><span >F7</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.F7"></span></el-col>
              <el-col :span="1"><span >F8</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F8"></span></el-col>
              <el-col :span="1"><span >F9</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F9"></span></el-col>
              <el-col :span="1"><span >F10</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F10"></span></el-col>
              <el-col :span="1"><span >F11</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F11"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >F12</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F12"></span></el-col>
              <el-col :span="1" ><span >F13</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.F13"></span></el-col>
              <el-col :span="1"><span >F14</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F14"></span></el-col>
              <el-col :span="1"><span >F15</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F15"></span></el-col>
              <el-col :span="1"><span >F16</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F16"></span></el-col>
              <el-col :span="1"><span >F17</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.F17"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE2"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE2"></span></el-col>
              <el-col :span="4"></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 162px;margin-left: 620px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >蒸发冷一体机组系数（制冷工况）</span>
              <i class="el-icon-bangzhu"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >K0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K0"></span></el-col>
              <el-col :span="1" ><span >K1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.K1"></span></el-col>
              <el-col :span="1"><span >K2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K2"></span></el-col>
              <el-col :span="1"><span >K3</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K3"></span></el-col>
              <el-col :span="1"><span >K4</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K4"></span></el-col>
              <el-col :span="1"><span >K5</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K5"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >K6</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K6"></span></el-col>
              <el-col :span="1" ><span >K7</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.K7"></span></el-col>
              <el-col :span="1"><span >K8</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K8"></span></el-col>
              <el-col :span="1"><span >K9</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K9"></span></el-col>
              <el-col :span="1"><span >K10</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K10"></span></el-col>
              <el-col :span="1"><span >K11</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K11"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >K12</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K12"></span></el-col>
              <el-col :span="1" ><span >K13</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.K13"></span></el-col>
              <el-col :span="1"><span >K14</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K14"></span></el-col>
              <el-col :span="1"><span >K15</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K15"></span></el-col>
              <el-col :span="1"><span >K16</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K16"></span></el-col>
              <el-col :span="1"><span >K17</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.K17"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE4"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE4"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 345px;margin-left: 620px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >冷冻水泵系数</span>
              <i class="el-icon-coin" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >A0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.A0"></span></el-col>
              <el-col :span="1" ><span >A1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.A1"></span></el-col>
              <el-col :span="1"><span >A2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.A2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE6"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE6"></span></el-col>
            </el-row>
          </el-card>
          <el-card class="box-card" style="margin: 10px;margin-top: 345px;margin-left: 10px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >冷却水泵系数</span>
              <i class="el-icon-coin" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >C0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.C0"></span></el-col>
              <el-col :span="1" ><span >C1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.C1"></span></el-col>
              <el-col :span="1"><span >C2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.C2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE7"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE7"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-left: 10px;margin-top: 485px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >冷水机组系数（制冷工况）</span>
              <i class="el-icon-bangzhu"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >B0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B0"></span></el-col>
              <el-col :span="1" ><span >B1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.B1"></span></el-col>
              <el-col :span="1"><span >B2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B2"></span></el-col>
              <el-col :span="1"><span >B3</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B3"></span></el-col>
              <el-col :span="1"><span >B4</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B4"></span></el-col>
              <el-col :span="1"><span >B5</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B5"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >B6</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B6"></span></el-col>
              <el-col :span="1" ><span >B7</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.B7"></span></el-col>
              <el-col :span="1"><span >B8</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B8"></span></el-col>
              <el-col :span="1"><span >B9</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B9"></span></el-col>
              <el-col :span="1"><span >B10</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B10"></span></el-col>
              <el-col :span="1"><span >B11</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B11"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >B12</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B12"></span></el-col>
              <el-col :span="1" ><span >B13</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.B13"></span></el-col>
              <el-col :span="1"><span >B14</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B14"></span></el-col>
              <el-col :span="1"><span >B15</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B15"></span></el-col>
              <el-col :span="1"><span >B16</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B16"></span></el-col>
              <el-col :span="1"><span >B17</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B17"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="1"><span >B18</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B18"></span></el-col>
              <el-col :span="1" ><span >B19</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.B19"></span></el-col>
              <el-col :span="1"><span >B20</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B20"></span></el-col>
              <el-col :span="1"><span >B21</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B21"></span></el-col>
              <el-col :span="1"><span >B22</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B22"></span></el-col>
              <el-col :span="1"><span >B23</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.B23"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE"></span></el-col>
              <el-col :span="4"></el-col>
            </el-row>
          </el-card>

          <el-button style="margin-left:800px;margin-top: 570px" type="primary" @click="onSubmit" icon="el-icon-edit-outline" >拟合</el-button>
          <el-button style="margin-left:90px" icon="el-icon-refresh">取消</el-button>
        </el-tab-pane>
        <el-tab-pane label="数据拟合（冷却塔）" name="second" style="height:683px">
          <el-card class="box-card" style="margin: 10px;margin-top: 0px;margin-left: 10px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >系数(功率)</span>
              <i class="el-icon-office-building" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="2"><span >功率</span></el-col>
              <el-col :span="1"><span >E0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.E0"></span></el-col>
              <el-col :span="1" ><span >E1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.E1"></span></el-col>
              <el-col :span="1"><span >E2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.E2"></span></el-col>
              <el-col :span="1"><span >E3</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.E3"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE9"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE9"></span></el-col>
            </el-row>
          </el-card>
          <el-card class="box-card" style="margin: 10px;margin-top: 0px;margin-left: 620px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >一对一 | 系数(冷幅)</span>
              <i class="el-icon-office-building" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="2" ><span >冷幅</span></el-col>
              <el-col :span="1"><span >D0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D0"></span></el-col>
              <el-col :span="1" ><span >D1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.D1"></span></el-col>
              <el-col :span="1"><span >D2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE8"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE8"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 150px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >二对一 | 系数(冷幅)</span>
              <i class="el-icon-office-building" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="2" ><span >冷幅</span></el-col>
              <el-col :span="1"><span >D0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D0"></span></el-col>
              <el-col :span="1" ><span >D1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.D1"></span></el-col>
              <el-col :span="1"><span >D2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE8"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE8"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 150px;margin-left: 620px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >三对一 | 系数(冷幅)</span>
              <i class="el-icon-office-building" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="2" ><span >冷幅</span></el-col>
              <el-col :span="1"><span >D0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D0"></span></el-col>
              <el-col :span="1" ><span >D1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.D1"></span></el-col>
              <el-col :span="1"><span >D2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE8"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE8"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 300px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >四对一 | 系数(冷幅)</span>
              <i class="el-icon-office-building" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="2" ><span >冷幅</span></el-col>
              <el-col :span="1"><span >D0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D0"></span></el-col>
              <el-col :span="1" ><span >D1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.D1"></span></el-col>
              <el-col :span="1"><span >D2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE8"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE8"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 300px;margin-left: 620px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >三对二 | 系数(冷幅)</span>
              <i class="el-icon-office-building" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="2" ><span >冷幅</span></el-col>
              <el-col :span="1"><span >D0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D0"></span></el-col>
              <el-col :span="1" ><span >D1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.D1"></span></el-col>
              <el-col :span="1"><span >D2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE8"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE8"></span></el-col>
            </el-row>
          </el-card>

          <el-card class="box-card" style="margin: 10px;margin-top: 450px;width:600px;position:absolute;background-color:#31629f;color:white">
            <div slot="header" class="clearfix">
              <span style="font-weight: bold" >四对三 | 系数(冷幅)</span>
              <i class="el-icon-office-building" style="margin-left: 10px"></i>
            </div>
            <el-row class="self-row" gutter="12">
              <el-col :span="2" ><span >冷幅</span></el-col>
              <el-col :span="1"><span >D0</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D0"></span></el-col>
              <el-col :span="1" ><span >D1</span></el-col>
              <el-col :span="3" class="out" ><span v-text="form.D1"></span></el-col>
              <el-col :span="1"><span >D2</span></el-col>
              <el-col :span="3" class="out"><span v-text="form.D2"></span></el-col>
            </el-row>
            <el-row class="self-row" gutter="12">
              <el-col :span="4"><span >MAPE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.MAPE8"></span></el-col>
              <el-col :span="4" style="text-align: center;"><label>|</label></el-col>
              <el-col :span="4"><span >RMSE</span></el-col>
              <el-col :span="6" style="text-align: left;color: #13ce66;"><span v-text="form.RMSE8"></span></el-col>
            </el-row>
          </el-card>

          <el-button style="margin-left:800px;margin-top: 545px" type="primary" @click="onSubmit" icon="el-icon-edit-outline" >拟合</el-button>
          <el-button style="margin-left:90px" icon="el-icon-refresh">取消</el-button>
        </el-tab-pane>
      </el-tabs>
    </el-form>
  </div>
</template>

<script>
export default {
  name: "App",
  components: {
  },
  data() {
    return {
      activeName: "second",
      form: {
        B0: "125.59",
        B1: "53.94",
        B2: "-52.23",
        B3: "0.06",
        B4: "-0.21",
        B5: "-33.38",
        B6: "-33.09",
        B7: "113.91",
        B8: "-113.92",
        B9: "66.29",
        B10: "-54.30",
        B11: "46.36",
        B12: "-2010.32",
        B13: "-2008.95",
        B14: "197.46",
        B15: "-197.46",
        B16: "4019.45",
        B17: "56.39",
        B18: "-90.57",
        B19: "32.59",
        B20: "2007.22",
        B21: "113.92",
        B22: "197.48",
        B23: "-3.39",
        MAPE: "4.1%",
        RMSE: "12.6%",
        F0: "125.59",
        F1: "53.94",
        F2: "-52.23",
        F3: "0.06",
        F4: "-0.21",
        F5: "-33.38",
        F6: "-33.09",
        F7: "113.91",
        F8: "-113.92",
        F9: "66.29",
        F10: "-54.30",
        F11: "46.36",
        F12: "-2010.32",
        F13: "-2008.95",
        F14: "197.46",
        F15: "-197.46",
        F16: "4019.45",
        F17: "56.39",
        MAPE2: "4.1%",
        RMSE2: "12%",
        J0: "125.59",
        J1: "53.94",
        J2: "-52.23",
        J3: "0.06",
        J4: "-0.21",
        J5: "-33.38",
        J6: "-33.09",
        J7: "113.91",
        J8: "-113.92",
        J9: "66.29",
        MAPE3: "4.1%",
        RMSE3: "12.6%",
        K0: "125.59",
        K1: "53.94",
        K2: "-52.23",
        K3: "0.06",
        K4: "-0.21",
        K5: "-33.38",
        K6: "-33.09",
        K7: "113.91",
        K8: "-113.92",
        K9: "66.29",
        K10: "-54.30",
        K11: "46.36",
        K12: "-2010.32",
        K13: "-2008.95",
        K14: "197.46",
        K15: "-197.46",
        K16: "4019.45",
        K17: "56.39",
        MAPE4: "4.1%",
        RMSE4: "12.6%",
        L0: "125.59",
        L1: "53.94",
        L2: "-52.23",
        L3: "0.06",
        L4: "-0.21",
        L5: "-33.38",
        L6: "-33.09",
        L7: "113.91",
        L8: "-113.92",
        L9: "66.29",
        MAPE5: "4.1%",
        RMSE5: "12.6%",
        A0: "125.59",
        A1: "53.94",
        A2: "-52.23",
        MAPE6: "4.1%",
        RMSE6: "12.6%",
        C0: "125.59",
        C1: "53.94",
        C2: "-52.23",
        MAPE7: "4.1%",
        RMSE7: "12.6%",
        D0: "125.59",
        D1: "53.94",
        D2: "-52.23",
        MAPE8: "4.1%",
        RMSE8: "12.6%",
        E0: "125.59",
        E1: "53.94",
        E2: "-52.23",
        E3: "53.94",
        MAPE9: "4.1%",
        RMSE9: "12.6%"
      }
    };
  },
  methods: {
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex % 2 == 1) {
        return "even-row";
      }
      return "";
    },
    handleClick(tab, event) {
      console.log(tab, event);
    },
    onSubmit() {
      console.log("submit!");
    }
  }
};
</script>

<style lang="scss">
  .app-main {
    background: #31629f;
  }

  .fit .self-row {
    font-size: 12px;
    margin: 8px;
  }

  .fit .out {
    color: #13ce66;
    white-space:nowrap;
    text-overflow:ellipsis;
    overflow:hidden;
    text-align:right;
  }

  .fit .el-card__header{
      background: #304156;
   }
  .fit .el-card {
      border-radius: 10px;
   }
</style>

