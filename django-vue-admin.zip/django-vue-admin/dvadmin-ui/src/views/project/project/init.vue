<template style="background: blue">
  <div class="init" >
    <el-card class="box-card" style="margin: 10px;margin-left: 20px;width:450px;position:absolute;background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >基础配置</span>
        <i class="el-icon-s-tools"></i>
      </div>
      <div>
        <div style="margin-bottom: 5px">
          <template>
             <span class="el-form-item-ex__label" >计算类型...........................................</span>
            <el-select v-model="base.calculationType" size="min"  placeholder="请选择">
              <el-option
                v-for="item in calculationTypes"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </template>
         </div>
         <div style="margin-bottom: 5px">
          <template>
             <span class="el-form-item-ex__label" >冷源类型...........................................</span>
            <el-select v-model="base.coldSourceType"  size="min"  placeholder="请选择">
              <el-option
                v-for="item in coldSourceTypes"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </template>
         </div>
         <div style="margin-bottom: 5px">
          <template>
             <span class="el-form-item-ex__label" >热源类型...........................................</span>
            <el-select v-model="base.hotSourceType" size="min"  placeholder="请选择">
              <el-option
                v-for="item in hotSourceTypes"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </template>
         </div>
      </div>
      <div>
        <span class="el-form-item-ex__label" >优化计算设定值................................</span>
        <div class="w-input-block">
          <div class="el-input">
            <input v-model="base.optimizationCalculationValue"  type="text" autocomplete="off" class="el-input__inner" >
           </div>
        </div>
      </div>
      <div>
        <span class="el-form-item-ex__label" >冷却水进出口温差......................(℃)</span>
        <div style="margin-left: 250px;margin-bottom: 5px">
          <div class="el-input">
            <input v-model="base.coolingWaterInT"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px">
            <i class="el-icon-minus" style="margin-left:10px"></i>
            <input v-model="base.coolingWaterOutT"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px;margin-left:10px">
           </div>
        </div>
      </div>
      <div>
        <span class="el-form-item-ex__label" >冷冻水进出口温差......................(℃)</span>
        <div style="margin-left: 250px;margin-bottom: 5px">
          <div class="el-input">
            <input v-model="base.chilledWaterInT"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px">
            <i class="el-icon-minus" style="margin-left:10px"></i>
            <input v-model="base.chilledWaterOutT"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px;margin-left:10px">
          </div>
        </div>
      </div>
    </el-card>
    <el-card class="box-card" style="margin: 10px;margin-left: 490px; width:450px; position:absolute; background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >冷却塔免费冷源计算设置</span>
        <i class="el-icon-s-tools"></i>
      </div>
      <div>
        <div>
          <span class="el-form-item-ex__label" >室外湿球温度..............................(℃)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input  v-model="CTFCS.outdoorWetBulbT" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >板换温差......................................(℃)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input  v-model="CTFCS.plateDiffT" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >板换效率......................................(%)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CTFCS.plateRate" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >最低负荷....................................(Kw)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CTFCS.miniLoad" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷却塔温差..................................(℃)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CTFCS.coolingTowerDiffT" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >供回水温差..................................(℃)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CTFCS.waterDiffT" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
      </div>
    </el-card>
    <el-card id="tableCard" class="box-card" style="margin: 10px;width:240px;position:absolute;margin-left: 960px;background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >负荷率与冷冻水出水温度</span>
        <i class="el-icon-stopwatch"></i>
      </div>
      <div>
      <template>
         <div id="app">
           <div style="margin-bottom: 5px;margin-top: 5px">
            <el-switch
              style="display: block"
              v-model="editModeEnabled"
              active-color="#1890ff"
              inactive-color="#BEBEBE"
              active-text=""
              inactive-text="">
             </el-switch>
           </div>
            <el-table
           :data="gridData"
           style="width: 100%;margin-bottom: 25px" size="mini" :row-class-name="tableRowClassName">
           <el-table-column
            label="负荷率(%)"
            align="center"
            min-width="50">
            <editable-cell slot-scope="{row}"
                    :can-edit="editModeEnabled"
                    v-model="row.percent">
             <span slot="content">{{row.percent}}</span>
            </editable-cell>
           </el-table-column>

           <el-table-column
            label="出水温度(℃)"
            align="center"
            min-width="50">
            <editable-cell slot-scope="{row}"
                    :can-edit="editModeEnabled"
                    v-model="row.temperature">
             <span slot="content">{{row.temperature}}</span>
            </editable-cell>
           </el-table-column>

          </el-table>
         </div>
        </template>
    </div>
    </el-card>

    <el-card class="box-card" style="margin: 10px;margin-left: 20px;margin-top:232px;width:450px;position:absolute;background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >冷却水泵</span>
        <i class="el-icon-setting"></i>
      </div>
      <div>
        <div>
          <span class="el-form-item-ex__label" >单台冷却水泵的额定流量.......(m3/h)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CoolingWP.flow"  type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台冷却水泵功率  .................. (Kw)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CoolingWP.power" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台冷却水泵扬程......................(m)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CoolingWP.lift" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷却水泵最多台数.....................(台)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CoolingWP.number" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷却水泵变频频率下限值...............</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CoolingWP.frequencyLowerLimit"  type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
      </div>
    </el-card>
    <el-card class="box-card" style="margin: 10px;width:450px;position:absolute;margin-top:232px;margin-left:490px;background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >冷却塔</span>
        <i class="el-icon-setting"></i>
      </div>
      <div>
        <div>
          <span class="el-form-item-ex__label" >单台冷却塔的额定流量..........(m3/h)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CT.flow"  type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台冷却塔风量.....................(m3/h)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CT.airVolume" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台冷却塔功率........................(Kw)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CT.power" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷却塔最多台数.........................(台)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CT.number" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div style="margin-bottom: 5px">
          <template>
            <span class="el-form-item-ex__label" >冷却塔运行模式................................</span>
            <el-select v-model="CT.mode" size="min"  placeholder="请选择">
              <el-option
                v-for="item in coolingTowerModes"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </template>
        </div>
      </div>
    </el-card>
    <el-card class="box-card" style="margin:10px; width:450px; position:absolute; margin-left: 20px; margin-top:430px; background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >冷水机组</span>
        <i class="el-icon-setting"></i>
      </div>
      <div>
        <div>
          <span class="el-form-item-ex__label" >单台额定冷水机组额定负荷.....(KW)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CWU.ratedLoad" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷水机组最多台数......................(台)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CWU.number" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台高效率冷负荷范围...............(%)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CWU.loadRange" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台冷水机组最低负荷..............(Kw)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CWU.miniLoad" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷却塔出水(机组允许)最低温度 .(℃)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="CWU.miniT"  type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
      </div>
    </el-card>
    <el-card class="box-card" style="margin: 10px;margin-left: 490px;margin-top:430px;width:450px;position:absolute;background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >冷冻水泵</span>
        <i class="el-icon-setting"></i>
      </div>
      <div>
        <div>
          <span class="el-form-item-ex__label" >单台冷冻水泵的额定流量........(m3/h)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="ChilledWP.ratedFlow"  type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台冷冻水泵扬程.......................(m)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="ChilledWP.lift" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >单台冷冻水泵功率.....................(Kw)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="ChilledWP.power" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷冻水泵台数..............................(台)</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="ChilledWP.number" type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >冷冻水泵变频频率下限值.................</span>
          <div class="w-input-block">
            <div class="el-input">
              <input v-model="ChilledWP.frequencyLowerLimit"  type="text" autocomplete="off" class="el-input__inner" >
             </div>
          </div>
        </div>
      </div>
    </el-card>
    <el-card class="box-card" style="margin: 10px;margin-left: 20px; width:450px; position:absolute;margin-top:630px;background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >制冷制热</span>
        <i class="el-icon-stopwatch"></i>
      </div>
      <div>
        <div>
          <span class="el-form-item-ex__label" >非制冷制热区温度......................(℃)</span>
          <div style="margin-left: 250px;margin-bottom: 5px">
            <div class="el-input">
              <input v-model="RH.refrigerationT"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px">
              <i class="el-icon-minus" style="margin-left:10px"></i>
              <input v-model="RH.heatingT"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px;margin-left:10px">
             </div>
          </div>
        </div>
        <div>
          <span class="el-form-item-ex__label" >制冷制热主机开启最低负荷......(Kw)</span>
          <div style="margin-left: 250px;margin-bottom: 5px">
            <div class="el-input">
              <input v-model="RH.refrigerationMiniP"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px">
              <i class="el-icon-minus" style="margin-left:10px"></i>
              <input v-model="RH.heatingMiniT"  type="text" autocomplete="off" class="el-input__inner" style="height: 20px;width: 60px;margin-left:10px">
             </div>
          </div>
        </div>
      </div>
    </el-card>
      <el-button style="margin-left:590px;margin-top: 680px" type="primary" @click="onSubmit" icon="el-icon-setting" >设定</el-button>
      <el-button style="margin-left:90px" @click="setDefault" icon="el-icon-refresh">重置</el-button>
  </div>
</template>

<script>
import EditableCell from "./EditableCell.vue";
import * as Init from '../../../api/project/init';

export default {
  name: "App",
  components: {
    EditableCell
  },
  data() {
    return {
      base: {
        calculationType: "2",
        coldSourceType: "3",
        hotSourceType: "2",
        optimizationCalculationValue: "6.0",
        coolingWaterInT: "4.0",
        coolingWaterOutT: "6.0",
        chilledWaterInT: "4.0",
        chilledWaterOutT: "8.0"
      },
      CTFCS: {
        outdoorWetBulbT: "28",
        plateDiffT: "1.5",
        plateRate: "95",
        miniLoad: "420",
        coolingTowerDiffT: "5",
        waterDiffT: "5",
      },
      CT: {
        flow: "720",
        airVolume: "500000",
        power: "22.0",
        number: "4",
        mode: "1"
      },
      CWU: {
        ratedLoad: "2814.0",
        number: "3",
        loadRange: "100.0",
        miniLoad: "422.0",
        miniT: "21.0"
      },
      ChilledWP: {
        ratedFlow: "533.0",
        lift: "41.0",
        power: "89.0",
        number: "3",
        frequencyLowerLimit: "0.6"
      },
      RH: {
        refrigerationT: "28.0",
        heatingT: "20.0",
        refrigerationMiniP: "400",
        heatingMiniT: "150"
      },
      CoolingWP: {
        flow: "650.0",
        power: "55",
        lift: "23",
        number: "3",
        frequencyLowerLimit: "0.65"
      },
      calculationTypes: [{
        value: "1",
        label: "单冷型"
      }, {
        value: "2",
        label: "冷暖型"
      }],
      coldSourceTypes: [{
        value: "1",
        label: "冷水机组+冷却塔"
      }, {
        value: "2",
        label: "风冷热泵机组"
      }, {
        value: "3",
        label: "一体化蒸发冷水机组"
      }],
      hotSourceTypes: [{
        value: "1",
        label: "锅炉"
      }, {
        value: "2",
        label: "风冷热泵机组"
      }],
      coolingTowerModes: [{
        value: "1",
        label: "自动计算"
      }, {
        value: "2",
        label: "一对一"
      }, {
        value: "3",
        label: "二对一"
      }, {
        value: "4",
        label: "三对一"
      }, {
        value: "5",
        label: "四对一"
      }, {
        value: "6",
        label: "三对二"
      }, {
        value: "7",
        label: "四对三"
      }],
      editModeEnabled: false,
      gridData: [
      {
        percent: "100%",
        temperature: "7.0"
      },
      {
        percent: "95%",
        temperature: "7.5"
      },
      {
        percent: "90%",
        temperature: "8.0"
      },
      {
        percent: "85%",
        temperature: "8.5"
      },
      {
        percent: "80%",
        temperature: "9.0"
      },
      {
        percent: "75%",
        temperature: "9.5"
      },
      {
        percent: "70%",
        temperature: "10.0"
      },
      {
        percent: "65%",
        temperature: "10.0"
      },
      {
        percent: "60%",
        temperature: "10.0"
      },
      {
        percent: "55%",
        temperature: "10.0"
      },
      {
        percent: "50%",
        temperature: "10.0"
      },
      {
        percent: "45%",
        temperature: "10.0"
      },
      {
        percent: "40%",
        temperature: "10.0"
      },
      {
        percent: "35%",
        temperature: "10.0"
      }]
    };
  },
  methods: {
    tableRowClassName({row, rowIndex}) {
      if (rowIndex % 2 == 1) {
        return "even-row";
      }
      return "odd-row";
    },
    setDefault(){
      Object.assign(this.$data, this.$options.data());
      this.msgSuccess("重置成功");
    },
    onSubmit() {
 /*     Init.listInitParam({key:"CWU"}).then((response) => {
        alert(JSON.stringify(response));
      });*/
      var base={key: "base", value: JSON.stringify(this.base)};
      Init.addInitParam(base);
      var CTFCS={key: "CTFCS", value: JSON.stringify(this.CTFCS)};
      Init.addInitParam(CTFCS);
      var CT={key: "CT", value: JSON.stringify(this.CT)};
      Init.addInitParam(CT);
      var CWU={key: "CWU", value: JSON.stringify(this.CWU)};
      Init.addInitParam(CWU);
      var ChilledWP={key: "ChilledWP", value: JSON.stringify(this.ChilledWP)};
      Init.addInitParam(ChilledWP);
      var RH={key: "RH", value: JSON.stringify(this.RH)};
      Init.addInitParam(RH);
      var CoolingWP={key: "CoolingWP", value: JSON.stringify(this.CoolingWP)};
      Init.addInitParam(CoolingWP);
      var LRACWOT={key: "LRACWOT", value: JSON.stringify(this.gridData)};
      Init.addInitParam(LRACWOT);
      this.msgSuccess("设定成功");
    }
  }
};
</script>

<style lang="scss">
  .app-main {
    background: #31629f;
  }

  .init .el-table .el-table__header-wrapper th, .el-table .el-table__fixed-header-wrapper th{
      background: #31629f;
      color: white;
  }
  .init  .el-card__header{
      background: #304156;
   }

  .init  .el-card {
      border-radius: 10px;
   }

  .init  .el-table th, .el-table td{
      padding: 0px;
   }
  .init  .edit-cell {
     min-height: 35px;
     cursor: pointer;
    }
   .init .el-form-item-ex__label{
        text-align: left;
        vertical-align: middle;
        float: left;
        font-size: 14px;
        color: white;
        line-height: 20px;
        padding: 0 12px 0 0;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        width: 240px;
   }

  .init .el-input__inner{
        line-height: 20px;
        height: 20px;
        width: 158px;
   }

   .init .w-input-block {
        margin-left: 250px;
        margin-bottom: 5px;
   }

  .init .text {
    font-size: 14px;
  }

  .init .item {
    margin-bottom: 18px;
  }

  .init .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }
  .init .clearfix:after {
    clear: both
  }

  .init .box-card {
    width: 480px;
  }

 .init .el-select .el-input .el-select__caret{
    margin-top:10px;
  }

 .init .el-input__suffix{
    right:10px;
  }

  .init .el-select > .el-input{
    margin-left: 10px;
  }

  .init  .el-table .even-row {
    background: #96FED1;
  }

   .init .el-table .odd-row{
    background: #84C1FF;
   }

  .init .el-card__body {
    padding-bottom: 12px;
    padding-top: 8px;
  }
</style>

