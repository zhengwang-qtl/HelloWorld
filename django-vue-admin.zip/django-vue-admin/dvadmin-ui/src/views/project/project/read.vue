<template>
  <div class="read">
    <el-tabs v-model="activeName" style="margin:10px">
      <el-tab-pane label="主机设备" name="first" style="height:683px">
        <template style="background: blue">
            <el-card class="box-card" style="margin: 10px; margin-top: 0px;position:absolute;width:422px;background-color:#31629f;color:white">
              <div slot="header" class="clearfix">
                <span style="font-weight: bold" >主机设备</span>
                <i class="el-icon-cpu"></i>
                 <el-select style="margin-left:70px" v-model="host_device_name" size="min"  placeholder="请选择">
                  <el-option
                    v-for="item in host_device_names"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value">
                  </el-option>
                </el-select>
                <el-button style="margin-left:15px;padding: 2px" type="success" @click="importHostDevice" icon="el-icon-upload2" ></el-button>
                <el-button type="info" style="padding: 2px" @click="cleanHostDevice" icon="el-icon-delete" ></el-button>
              </div>
              <div>
              <template>
                 <div id="app" >
                  <el-table
                    :data="tableHostDevice"
                    style=""
                    size="mini"
                    slot="empty"
                    empty-text="暂无数据"
                    height="560px"
                    :row-class-name="tableRowClassName">
                    <div slot="empty">
                      <p>暂无数据</p>
                    </div>
                    <el-table-column
                      align="center"
                      prop="load_percentage"
                      :label="'负荷\n百分比\n%'"
                      width="45">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="cooling_capacity"
                      :label="'制冷\n量\nKw'"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="power_percentage"
                      :label="'功率\n百分比\n%'"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="input_power"
                      :label="'输入\n功率\nKw'"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="chilled_water_outlet_temperature"
                      label="冷冻水出水温度 ℃"
                      width="45">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="chilled_water_inlet_temperature"
                      label="冷冻水进水温度 ℃"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="cooling_water_outlet_temperature"
                      label="冷却水出水温度 ℃"
                      width="45">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="cooling_water_inlet_temperature"
                      label="冷却水进水温度 ℃"
                      width="45">
                    </el-table-column>
                    <el-table-column
                      align="left"
                      prop="cop"
                      label="COP"
                      width="40">
                    </el-table-column>
                  </el-table>
                  <el-pagination
                    style="margin-top:10px"
                    background
                    small
                    layout="prev, pager, next"
                    :current-page="tableCoolingTowerPage.pageNum"
                    :page-size="tableHostDevicePage.pageSize"
                    :total="tableHostDevicePage.total"
                    @current-change="handleHostDevicePageChange"
                    >
                  </el-pagination>
                 </div>
                </template>
            </div>
            </el-card>
            <el-card class="box-card" style="margin: 10px; margin-top: 0px;margin-left:442px;position:absolute;width:382px;background-color:#31629f;color:white">
              <div slot="header" class="clearfix">
                <span style="font-weight: bold" >风冷热泵机组</span>
                <i class="el-icon-wind-power"></i>
                <el-button style="margin-left:185px;padding: 2px" type="success" @click="importAircooledHeatpumpUnit" icon="el-icon-upload2" ></el-button>
                <el-button type="info" style="padding: 2px" @click="cleanAircooledHeatpumpUnit" icon="el-icon-delete" ></el-button>
              </div>
              <div>
                <el-table
                  :data="tableAircooledHeatpumpUnit"
                  style=""
                  size="mini"
                  empty-text="暂无数据"
                  height="560px"
                  :row-class-name="tableRowClassName">
                  <el-table-column
                    align="center"
                    prop="load_percentage"
                    :label="'负荷\n百分比\n%'"
                    width="45">
                  </el-table-column>
                  <el-table-column
                    align="center"
                    prop="cooling_capacity"
                    :label="'制冷\n量\nKw'"
                    width="40">
                  </el-table-column>
                  <el-table-column
                    align="center"
                    prop="power_percentage"
                    :label="'功率\n百分比\n%'"
                    width="45">
                  </el-table-column>
                  <el-table-column
                    align="center"
                    prop="input_power"
                    :label="'输入\n功率\nKw'"
                    width="45">
                  </el-table-column>
                  <el-table-column
                    align="center"
                    prop="outlet_temperature"
                    :label="'出水\n温度\n℃'"
                    width="40">
                  </el-table-column>
                  <el-table-column
                    align="center"
                    prop="inlet_temperature"
                    :label="'进水\n温度\n℃'"
                    width="40">
                  </el-table-column>
                  <el-table-column
                    align="center"
                    prop="outdoor_dry_bulb_temperature"
                    :label="'室外干\n球温度\n℃'"
                    width="40">
                  </el-table-column>
                  <el-table-column
                    align="left"
                    prop="cop"
                    label="COP"
                    width="45">
                  </el-table-column>
                </el-table>
                <el-pagination
                style="margin-top:10px"
                background
                small
                layout="prev, pager, next"
                :current-page="tableAircooledHeatpumpUnitPage.pageNum"
                :page-size="tableAircooledHeatpumpUnitPage.pageSize"
                :total="tableAircooledHeatpumpUnitPage.total"
                @current-change="handleAircooledHeatpumpUnitPageChange"
                >
              </el-pagination>
            </div>
            </el-card>
            <el-card class="box-card" style="margin: 10px; margin-top: 0px;margin-left:834px;position:absolute;width:382px;background-color:#31629f;color:white">
              <div slot="header" class="clearfix">
                <span style="font-weight: bold" >蒸发冷一体机</span>
                <i class="el-icon-coin"></i>
                <el-button style="margin-left: 185px;padding: 2px" type="success" @click="importEvaporativeCoolingMachine" icon="el-icon-upload2" ></el-button>
                <el-button type="info" style="padding: 2px" @click="cleanEvaporativeCoolingMachine" icon="el-icon-delete" ></el-button>
              </div>
              <div>
              <template>
                 <div id="app" >
                  <el-table
                    :data="tableEvaporativeCoolingMachine"
                    style=""
                    size="mini"
                    empty-text="暂无数据"
                    height="560px"
                    :row-class-name="tableRowClassName">
                    <el-table-column
                      align="center"
                      prop="load_percentage"
                      :label="'负荷\n百分比\n%'"
                      width="45">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="cooling_capacity"
                      :label="'制冷\n量\nKw'"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="power_percentage"
                      :label="'功率\n百分比\n%'"
                      width="45">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="input_power"
                      :label="'输入\n功率\nKw'"
                      width="45">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="outlet_temperature"
                      :label="'出水\n温度\n℃'"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="inlet_temperature"
                      :label="'进水\n温度\n℃'"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="center"
                      prop="outdoor_wet_bulb_temperature"
                      :label="'室外湿\n球温度\n℃'"
                      width="40">
                    </el-table-column>
                    <el-table-column
                      align="left"
                      prop="cop"
                      label="COP"
                      width="45">
                    </el-table-column>
                  </el-table>
                  <el-pagination
                  style="margin-top:10px"
                  background
                  small
                  layout="prev, pager, next"
                  :current-page="tableEvaporativeCoolingMachinePage.pageNum"
                  :page-size="tableEvaporativeCoolingMachinePage.pageSize"
                  :total="tableEvaporativeCoolingMachinePage.total"
                  @current-change="handleEvaporativeCoolingMachinePageChange"
                  >
                </el-pagination>
                 </div>
                </template>
            </div>
            </el-card>
        </template>
      </el-tab-pane>
      <el-tab-pane label="水泵、冷却塔、负荷、室外干球温度、室外湿球温度" name="second" style="height:683px">
        <el-card class="box-card" style="margin: 10px; margin-top: 0px;margin-left:10px;position:absolute;width:342px;background-color:#31629f;color:white">
          <div slot="header" class="clearfix">
            <span style="font-weight: bold" >冷却塔</span>
            <i class="el-icon-office-building"></i>
            <el-button style="margin-left:190px;padding: 2px" type="success" @click="importCoolingTower" icon="el-icon-upload2" ></el-button>
            <el-button type="info" style="padding: 2px" @click="cleanCoolingTower" icon="el-icon-delete" ></el-button>
          </div>
          <div>
          <template>
             <div id="app" >
              <el-table
                :data="tableCoolingTower"
                style=""
                size="mini"
                empty-text="暂无数据"
                height="560px"
                :row-class-name="tableRowClassName">
                <el-table-column
                  align="center"
                      prop="wet_bulb_temperature"
                  :label="'湿球\n温度\n℃'"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="center"
                      prop="cold_width"
                  label="冷幅"
                  width="40"
                  show-overflow-tooltip >
                </el-table-column>
                <el-table-column
                  align="center"
                      prop="inlet_water_temperature"
                  :label="'进水\n温度\n℃'"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="center"
                      prop="outlet_water_temperature"
                  :label="'出水\n温度\n℃'"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="center"
                  prop="water_flow"
                  :label="'水流\n量\nm3/h'"
                  width="40">
                </el-table-column>
                <el-table-column
                  align="center"
                  prop="air_flow"
                  :label="'空气\n流量\nm3/h'"
                  width="40">
                </el-table-column>
                <el-table-column
                  align="left"
                  prop="fan_power"
                  :label="'风机\n功率\nKw'"
                  width="45">
                </el-table-column>
              </el-table>
              <el-pagination
                style="margin-top:10px"
                background
                small
                layout="prev, pager, next"
                :current-page="tableCoolingTowerPage.pageNum"
                :page-size="tableCoolingTowerPage.pageSize"
                :total="tableCoolingTowerPage.total"
                @current-change="handleCoolingTowerPageChange"
                >
              </el-pagination>
             </div>
            </template>
        </div>
        </el-card>
        <el-card class="box-card" style="margin: 10px; margin-top: 0px;margin-left:362px;position:absolute;width:352px;background-color:#31629f;color:white">
          <div slot="header" class="clearfix">
            <span style="font-weight: bold" >负荷、室外干/湿球温度</span>
            <i class="el-icon-stopwatch"></i>
            <el-button style="margin-left: 85px;padding: 2px" type="success" @click="importLoadDrywetbulbtemperature" icon="el-icon-upload2" ></el-button>
            <el-button type="info" style="padding: 2px" @click="cleanLoadDrywetbulbtemperature" icon="el-icon-delete" ></el-button>
          </div>
          <div>
          <template>
             <div id="app" >
              <el-table
                :data="tableLoadDrywetbulbtemperature"
                style=""
                size="mini"
                empty-text="暂无数据"
                height="560px"
                :row-class-name="tableRowClassName">
                <el-table-column
                  align="center"
                  prop="year"
                  label="年"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="center"
                  prop="month"
                  label="月"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="center"
                      prop="day"
                  label="日"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="center"
                  prop="time"
                  label="时"
                  width="40">
                </el-table-column>
                <el-table-column
                  align="center"
                      prop="load"
                  label="负荷"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="center"
                  prop="outdoor_dry_bulb_temperature"
                  :label="'湿球\n温度\n℃'"
                  width="45">
                </el-table-column>
                <el-table-column
                  align="left"
                  prop="outdoor_wet_bulb_temperature"
                  :label="'干球\n温度\n℃'"
                  width="45">
                </el-table-column>
              </el-table>
              <el-pagination
                style="margin-top:10px"
                background
                small
                layout="prev, pager, next"
                :current-page="tableLoadDrywetbulbtemperaturePage.pageNum"
                :page-size="tableLoadDrywetbulbtemperaturePage.pageSize"
                :total="tableLoadDrywetbulbtemperaturePage.total"
                @current-change="handleLoadDrywetbulbtemperaturePageChange"
                >
              </el-pagination>
             </div>
            </template>
        </div>
        </el-card>
        <el-card class="box-card" style="margin: 10px; margin-top: 0px;width:240px;position:absolute;margin-left: 720px;background-color:#31629f;color:white">
        <div slot="header" class="clearfix">
          <span style="font-weight: bold" >冷冻水泵</span>
          <i class="el-icon-coin"></i>
          <el-button style="margin-left: 70px;padding: 2px" type="success" @click="importChilledWaterPump" icon="el-icon-upload2" ></el-button>
          <el-button type="info" style="padding: 2px" @click="cleanChilledWaterPump" icon="el-icon-delete" ></el-button>
        </div>
        <div>
        <template>
           <div id="app">
              <el-table
             :data="tableChilledWaterPump"
             style="width: 100%"
             size="mini"
             :row-class-name="tableRowClassName"
             :show-header="false"
             empty-text="暂无数据">
             <el-table-column
              align="center"
              min-width="50"
              prop="key" >
             </el-table-column>
             <el-table-column
              align="center"
              min-width="50"
              prop="value">
             </el-table-column>
            </el-table>
           </div>
          </template>
      </div>
      </el-card>
      <el-card class="box-card" style="margin: 10px; margin-top: 0px;width:240px;position:absolute;margin-left: 970px;background-color:#31629f;color:white">
        <div slot="header" class="clearfix">
          <span style="font-weight: bold" >冷却水泵</span>
          <i class="el-icon-coin"></i>
          <el-button style="margin-left: 70px;padding: 2px" type="success" @click="importCoolingWaterPump" icon="el-icon-upload2" ></el-button>
          <el-button type="info" style="padding: 2px" @click="cleanCoolingWaterPump" icon="el-icon-delete" ></el-button>
        </div>
        <div>
        <template>
           <div id="app">
              <el-table
             :data="tableCoolingWaterPump"
             style="width: 100%"
             size="mini"
             :row-class-name="tableRowClassName"
             :show-header="false"
             empty-text="暂无数据">
             <el-table-column
              align="center"
              min-width="50"
              prop="key" >
             </el-table-column>
             <el-table-column
              align="center"
              min-width="50"
              prop="value">
             </el-table-column>
            </el-table>
           </div>
          </template>
      </div>
      </el-card>
      </el-tab-pane>
    </el-tabs>
    <div>
      <el-dialog :title="importTitle" :visible.sync="importOpen" width="400px" append-to-body >
        <Import ref="importFile" :funcs="funcs" @input="submitFile">
        </Import>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="submitFile">确 定</el-button>
          <el-button @click="importOpen = false">取 消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import Import from "@/components/Import/index";
import * as Read from "../../../api/project/read";

export default {
  name: "App1",
  components: {
    Import
  },
  data() {
    return {
      importOpen: false,
      importTitle: "导入",
      funcs: [],
      activeName: "first",
      host_device_names: [{
        value: "magnetic_levitation",
        label: "磁悬浮"
      }, {
        value: "centrifuge",
        label: "离心机"
      }, {
        value: "screw_machine",
        label: "螺杆机"
      }],
      host_device_name: "magnetic_levitation",
      tableHostDevicePage: {
        total: 0,
        pageNum: 1,
        pageSize: 14
      },
      tableHostDevice: [],
      tableAircooledHeatpumpUnitPage: {
        total: 0,
        pageNum: 1,
        pageSize: 14
      },
      tableAircooledHeatpumpUnit: [],
      tableEvaporativeCoolingMachinePage: {
        total: 0,
        pageNum: 1,
        pageSize: 14
      },
      tableEvaporativeCoolingMachine: [],
      tableCoolingTowerPage: {
        total: 0,
        pageNum: 1,
        pageSize: 14
      },
      tableCoolingTower: [],
      tableLoadDrywetbulbtemperaturePage: {
        total: 0,
        pageNum: 1,
        pageSize: 14
      },
      tableLoadDrywetbulbtemperature: [],
      tableChilledWaterPump: [],
      tableCoolingWaterPump: []
    };
  },
  mounted() {
    this.handleCoolingTowerPageChange(1);
  },
  methods: {
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex % 2 == 1) {
        return "even-row";
      }
      return "odd-row";
    },
    submitFile() {
      this.importOpen = false;
      this.$refs.importFile.fileList = [];
      this.$refs.importFile.submitFileForm();
    },
    importSuccess() {
      switch (this.funcs[0].name) {
          case "CoolingTower":
            this.handleCoolingTowerPageChange(1);
            break;
          case "AircooledHeatpumpUnit":
            this.handleAircooledHeatpumpUnitPageChange(1);
            break;
          case "EvaporativeCoolingMachine":
            this.handleEvaporativeCoolingMachinePageChange(1);
            break;
          case "HostDevice":
            this.handleHostDevicePageChange(1);
            break;
          case "LoadDrywetbulbtemperature":
            this.handleLoadDrywetbulbtemperaturePageChange(1);
            break;
          case "ChilledWaterPump":
            this.readChilledWaterPump();
            break;
          case "CoolingWaterPump":
            this.readCoolingWaterPump();
            break;
          default:
            console.log(this.funcs[0].name);
      }
    },
    importCoolingTower() {
      this.funcs = [
        { name: "CoolingTower", type: "import", label: "导入", success: this.importSuccess, api: Read.importCoolingTower, template_api: Read.importCoolingTowerTemplate }
      ];
      this.importOpen = true;
    },
    handleCoolingTowerPageChange(currentPage) {
      this.tableCoolingTowerPage.pageNum = currentPage;
      Read.listCoolingTower({ "pageNum": currentPage, "pageSize": 14 }).then((response) => {
        this.tableCoolingTowerPage.total = response.data.count;
        this.tableCoolingTower = response.data.results;
      });
    },
    cleanCoolingTower() {
      Read.cleanCoolingTower();
      this.tableCoolingTowerPage.total = 0;
      this.tableCoolingTower = [];
    },
    importAircooledHeatpumpUnit() {
      this.funcs = [
        { name: "AircooledHeatpumpUnit", type: "import", label: "导入", success: this.importSuccess, api: Read.importAircooledHeatpumpUnit, template_api: Read.importAircooledHeatpumpUnitTemplate }
      ];
      this.importOpen = true;
    },
    handleAircooledHeatpumpUnitPageChange(currentPage) {
      this.tableAircooledHeatpumpUnitPage.pageNum = currentPage;
      Read.listAircooledHeatpumpUnit({ "pageNum": currentPage, "pageSize": 14 }).then((response) => {
        this.tableAircooledHeatpumpUnitPage.total = response.data.count;
        this.tableAircooledHeatpumpUnit = response.data.results;
      });
    },
    cleanAircooledHeatpumpUnit() {
      Read.cleanAircooledHeatpumpUnit();
      this.tableAircooledHeatpumpUnitPage.total = 0;
      this.tableAircooledHeatpumpUnit = [];
    },
    importEvaporativeCoolingMachine() {
      this.funcs = [
        { name: "EvaporativeCoolingMachine", type: "import", label: "导入", success: this.importSuccess, api: Read.importEvaporativeCoolingMachine, template_api: Read.importEvaporativeCoolingMachineTemplate }
      ];
      this.importOpen = true;
    },
    handleEvaporativeCoolingMachinePageChange(currentPage) {
      this.tableEvaporativeCoolingMachinePage.pageNum = currentPage;
      Read.listEvaporativeCoolingMachine({ "pageNum": currentPage, "pageSize": 14 }).then((response) => {
        this.tableEvaporativeCoolingMachinePage.total = response.data.count;
        this.tableEvaporativeCoolingMachine = response.data.results;
      });
    },
    cleanEvaporativeCoolingMachine() {
      Read.cleanEvaporativeCoolingMachine();
      this.tableEvaporativeCoolingMachinePage.total = 0;
      this.tableEvaporativeCoolingMachine = [];
    },
    importHostDevice() {
      this.funcs = [
        { name: "HostDevice", type: "import", label: "导入", success: this.importSuccess, api: Read.importHostDevice, template_api: Read.importHostDeviceTemplate }
      ];
      this.importOpen = true;
    },
    handleHostDevicePageChange(currentPage) {
      this.tableHostDevicePage.pageNum = currentPage;
      Read.listHostDevice({ "pageNum": currentPage, "pageSize": 14 }).then((response) => {
        this.tableHostDevicePage.total = response.data.count;
        this.tableHostDevice = response.data.results;
      });
    },
    cleanHostDevice() {
      Read.cleanHostDevice();
      this.tableHostDevicePage.total = 0;
      this.tableHostDevice = [];
    },
    importLoadDrywetbulbtemperature() {
      this.funcs = [
        { name: "LoadDrywetbulbtemperature", type: "import", label: "导入", success: this.importSuccess, api: Read.importLoadDrywetbulbtemperature, template_api: Read.importLoadDrywetbulbtemperatureTemplate }
      ];
      this.importOpen = true;
    },
    handleLoadDrywetbulbtemperaturePageChange(currentPage) {
      this.tableLoadDrywetbulbtemperaturePage.pageNum = currentPage;
      Read.listLoadDrywetbulbtemperature({ "pageNum": currentPage, "pageSize": 14 }).then((response) => {
        this.tableLoadDrywetbulbtemperaturePage.total = response.data.count;
        this.tableLoadDrywetbulbtemperature = response.data.results;
      });
    },
    cleanLoadDrywetbulbtemperature() {
      Read.cleanLoadDrywetbulbtemperature();
      this.tableLoadDrywetbulbtemperaturePage.total = 0;
      this.tableLoadDrywetbulbtemperature = [];
    },
    importChilledWaterPump() {
      this.funcs = [
        { name: "ChilledWaterPump", type: "import", label: "导入", success: this.importSuccess, api: Read.importChilledWaterPump, template_api: Read.importChilledWaterPumpTemplate }
      ];
      this.importOpen = true;
    },
    readChilledWaterPump() {
      Read.listChilledWaterPump({ "pageNum": "all" }).then((response) => {
        this.tableChilledWaterPump = response.data;
      });
    },
    cleanChilledWaterPump() {
      Read.cleanChilledWaterPump();
      this.tableChilledWaterPump = [];
    },
    importCoolingWaterPump() {
      this.funcs = [
        { name: "CoolingWaterPump", type: "import", label: "导入", success: this.importSuccess, api: Read.importCoolingWaterPump, template_api: Read.importCoolingWaterPumpTemplate }
      ];
      this.importOpen = true;
    },
    readCoolingWaterPump() {
      Read.listCoolingWaterPump({ "pageNum": "all" }).then((response) => {
        this.tableCoolingWaterPump = response.data;
      });
    },
    cleanCoolingWaterPump() {
      Read.cleanCoolingWaterPump();
      this.tableCoolingWaterPump = [];
    }
  }
};
</script>

<style lang='scss'>
  .app-main {
    background: #31629f;
  }

  .read .el-table .cell{
    padding-left:1px;
    padding-right:1px;
  }
  .read .el-table th > .cell{
    padding-left:1px;
    padding-right:1px;
    font-weight:600;
    font-size:8px;
  }
  .read .el-table .el-table__header-wrapper th, .el-table .el-table__fixed-header-wrapper th{
      background: #31629f;
      color: white;
  }
  .read .el-table--mini{
    font-size:8px;
  }

  .read .el-table .even-row {
    background: #96FED1;
  }

   .read .el-table .odd-row{
    background: #84C1FF;
   }

  .read .el-input__inner{
      line-height: 20px;
      height: 20px;
      width: 158px;
   }

  .read .el-select .el-input .el-select__caret{
    margin-top:10px;
  }

  .read .el-input__suffix{
    right:10px;
  }

  .read .el-select > .el-input{
    margin-left: 10px;
  }

  .read .el-card {
      border-radius: 10px;
   }

  .read .el-card__header{
      background: #304156;
   }

  .read .el-table th>.cell{
    white-space: pre-wrap;
    line-height: 15px;
  }

  .read .el-card__body {
    padding: 15px 20px 20px 20px;
  }
</style>
