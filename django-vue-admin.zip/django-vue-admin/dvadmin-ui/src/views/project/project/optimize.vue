<template>
  <div class="optimize" >
    <el-card class="box-card" style="margin: 10px; margin-left: 20px;position:absolute;width: 1207px;background-color:#31629f;color:white">
      <div slot="header" class="clearfix">
        <span style="font-weight: bold" >优化计算</span>
        <i class="el-icon-s-promotion"></i>
        <el-button style="margin-left:810px;padding: 8px" type="primary" @click="onSubmit" icon="el-icon-edit-outline" >优化计算</el-button>
        <el-button style="margin-left:30px;padding: 8px" icon="el-icon-refresh">取消</el-button>
      </div>
      <div id="app" >
        <el-table
          :data="tableData"
          size="mini"
          slot="empty"
          empty-text="暂无数据"
          height="610px"
          >
          <div slot="empty">
            <p>没有记录哦~</p>
          </div>
          <el-table-column
            align="center"
            prop="tc1"
            label="年"
            width="45"
            class-name="first-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc2"
            label="月"
            width="40"
            class-name="first-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc3"
            label="日"
            width="40"
            class-name="first-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc4"
            label="时"
            width="45"
            class-name="first-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc5"
            label="负荷"
            width="45"
            class-name="second-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc6"
            :label="'湿球\n温度\n℃'"
            width="45"
            class-name="second-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc7"
            :label="'干球\n温度\n℃'"
            width="45"
            class-name="second-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc8"
            :label="'单机负荷\n百分比\n%'"
            width="50"
            class-name="second-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc9"
            :label="'系统负荷\n百分比\n%'"
            width="50"
            class-name="second-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc10"
            :label="'冷冻水\n出水温度\n℃'"
            width="50"
            class-name="third-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc11"
            :label="'冷冻水\n回水温度\n℃'"
            width="50"
            class-name="third-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc12"
            :label="'冷冻水\n泵流量\nm3/h'"
            width="50"
            class-name="third-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc13"
            :label="'冷冻水\n泵频率\nHz'"
            width="45"
            class-name="third-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc14"
            :label="'冷却水\n出水温度\n℃'"
            width="50"
            class-name="fourth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc15"
            :label="'冷却水\n回水温度\n℃'"
            width="50"
            class-name="fourth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc16"
            :label="'冷却水\n泵流量\nm3/h'"
            width="50"
            class-name="fourth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc17"
            :label="'冷却水\n泵频率\nHz'"
            width="45"
            class-name="fourth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc18"
            :label="'冷却塔\n冷幅\n℃'"
            width="45"
            class-name="fourth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc19"
            :label="'主机\n功率\nKw'"
            width="55"
            class-name="fifth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc20"
            :label="'冷冻水\n泵功率\nKw'"
            width="45"
            class-name="fifth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc21"
            :label="'冷却水\n泵功率\nKw'"
            width="45"
            class-name="fifth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc22"
            :label="'冷却塔\n功率\nKw'"
            width="45"
            class-name="fifth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc23"
            :label="'总\n功率\nKw'"
            width="45"
            class-name="fifth-batch">
          </el-table-column>
          <el-table-column
            align="center"
            prop="tc24"
            :label="'系统\nCOP\nKw'"
            width="45"
            class-name="sixth-batch">
          </el-table-column>
          <el-table-column
            align="left"
            prop="tc25"
            :label="'设备开\n启台数\n台'"
            width="45"
            class-name="sixth-batch">
          </el-table-column>
        </el-table>
        <el-pagination
          style="margin-top:10px"
          background
          small
          layout="prev, pager, next"
          :total="1000">
        </el-pagination>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  name: "App1",
  components: {
  },
  data() {
    return {
      tableData: [{
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1,
        "tc5": 8442.0,
        "tc6": 28.0,
        "tc7": "",
        "tc8": 99.5,
        "tc9": 99.5,
        "tc10": 7.0,
        "tc11": 13.45,
        "tc12": 372.57,
        "tc13": 34.95,
        "tc14": 30.43,
        "tc15": 34.43,
        "tc16": 650.0,
        "tc17": 50,
        "tc18": 2.435,
        "tc19": 1388.09,
        "tc20": 68.15,
        "tc21": 161.75,
        "tc22": 66.0,
        "tc23": 1706.00,
        "tc24": 4.92,
        "tc25": 3
      }]
    };
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event);
    },
    onSubmit() {
      console.log("submit!");
    }
  }
};
</script>

<style lang="scss">
  .app-main {
    background: #31629f;
  }

  .optimize .el-table .cell{
    padding-left:1px;
    padding-right:1px;
  }
  .optimize .el-table th > .cell{
    padding-left:1px;
    padding-right:1px;
    font-weight:600;
    font-size:8px;
  }
  .optimize .el-table .el-table__header-wrapper th, .el-table .el-table__fixed-header-wrapper th{
      background: #31629f;
      color: white;
  }
  .optimize .el-table--mini{
    font-size:8px;
  }
  .optimize .el-table th>.cell{
    white-space: pre-wrap;
    line-height: 15px;
  }

  .optimize .el-card__header{
      background: #304156;
   }

  .optimize .el-card {
      border-radius: 10px;
   }
  .optimize .first-batch {
    background: #84C1FF;
  }
  .optimize .second-batch {
    background: #96FED1;
  }
  .optimize .third-batch {
    background: #CCFF80;
  }
  .optimize .fourth-batch {
    background: #FFFF93;
  }
  .optimize .fifth-batch {
    background: #FFE66F;
  }
  .optimize .sixth-batch {
    background: #FFAD86;
  }

</style>
