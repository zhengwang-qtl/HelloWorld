<template style="background: blue">
  <div class="dashboard" >
    <el-form ref="form" >
      <el-card class="box-card" style="margin: 10px; margin-left: 20px;position:absolute;width: 212px;height: 310px;background-color:#31629f;color:white">
        <div id="app" >
          <el-table
            :data="tableData"
            size="mini"
            slot="empty"
            empty-text="暂无数据"
            height="250px" >
            <div slot="empty">
              <p>没有记录哦~</p>
            </div>
            <el-table-column
              align="center"
              prop="tc1"
              label="年"
              width="45"
              class-name="first-batch">
            </el-table-column>
            <el-table-column
              align="center"
              prop="tc2"
              label="月"
              width="40"
              class-name="first-batch">
            </el-table-column>
            <el-table-column
              align="center"
              prop="tc3"
              label="日"
              width="40"
              class-name="first-batch">
            </el-table-column>
            <el-table-column
              align="center"
              prop="tc4"
              label="时"
              width="45"
              class-name="first-batch">
            </el-table-column>
          </el-table>
          <el-row style="margin-top:15px" class="self-row-1" gutter="12">
            <el-col :span="16"><span >动态模拟间隔</span></el-col>
            <el-col :span="8" class="out"><span >5s</span></el-col>
          </el-row>
        </div>
      </el-card>
      <el-card class="box-card" style="margin: 10px; margin-top: 330px; margin-left: 20px; width:212px; position:absolute;background-color:#31629f;color:white">
        <el-row class="self-row-1" gutter="12" style="text-align: center">
            <el-col :span="24"><span style="color: black;font-weight: bolder;font-size: 16px">设备运行台数</span></el-col>
        </el-row>
        <el-row class="self-row-1" gutter="12">
          <el-col :span="8"><span >主机</span></el-col>
          <el-col :span="16" class="out"><span >1台</span></el-col>
        </el-row>
        <el-row class="self-row-1" gutter="12">
          <el-col :span="12"><span >冷冻泵</span></el-col>
          <el-col :span="12" class="out"><span >1台</span></el-col>
        </el-row>
        <el-row class="self-row-1" gutter="12">
          <el-col :span="12"><span >冷却泵</span></el-col>
          <el-col :span="12" class="out"><span >1台</span></el-col>
        </el-row>
        <el-row class="self-row-1" gutter="12">
          <el-col :span="12"><span >冷却塔</span></el-col>
          <el-col :span="12" class="out"><span >1台</span></el-col>
        </el-row>
      </el-card>
      <el-card class="box-card" style="margin: 10px; margin-top: 510px ;margin-left: 20px;position:absolute;width: 212px;height: 240px;background-color:#31629f;color:white">
          <div id="frequencyChart" style="width: 180px; height: 210px"></div>
      </el-card>

       <el-card class="box-card" style="margin: 10px; margin-left: 240px; width: 730px; height: 740px ;position:absolute;background-color:#31629f;color:white">
        <div id="chart3" style="width: 700px; height: 230px; "></div>
        <div>
          <div id="chart2" style="width: 520px; height: 250px; "></div>
        </div>
        <div id="chart4" style="width: 460px; height: 240px; "></div>
      </el-card>
      <div id="pieChart" style="width: 200px; height: 200px; position:absolute;margin-left: 770px;margin-top:290px "></div>
      <el-card class="box-card" style="margin: 10px; margin-left: 980px; width: 250px; height: 740px ; position:absolute;background-color:#31629f;color:white">
        <div id="t1Chart" style="width: 210px; height: 240px;margin-top: 15px"></div>
        <div id="t2Chart" style="width: 210px; height: 240px; "></div>
        <div id="t3Chart" style="width: 210px; height: 240px; "></div>
      </el-card>
      <el-card class="box-card" style="margin: 10px; margin-left: 730px; margin-top: 530px;width: 240px; height: 220px ; position:absolute;background-color:#31629f;color:white">
        <div>
          <el-row class="self-row-1" gutter="12" style="text-align: center">
            <el-col :span="24"><span style="color: black;font-weight: bolder;font-size: 16px">能耗统计</span></el-col>
          </el-row>
          <el-row class="self-row-1" gutter="12">
            <el-col :span="6"><span >时间</span></el-col>
            <el-col :span="18" class="out"><span >20210101 - 20210301</span></el-col>
          </el-row>
          <el-row class="self-row-1" gutter="12">
            <el-col :span="12"><span >总功耗</span></el-col>
            <el-col :span="12" class="out"><span >17110Kw</span></el-col>
          </el-row>
          <el-row class="self-row-1" gutter="12">
            <el-col :span="12"><span >总负荷</span></el-col>
            <el-col :span="12" class="out"><span >84000Kw</span></el-col>
          </el-row>
          <el-row class="self-row-1" gutter="12">
            <el-col :span="12"><span >总平均COP</span></el-col>
            <el-col :span="12" class="out"><span >5.15</span></el-col>
          </el-row>
          <div style="margin-left: 8px; margin-top: 25px">
            <el-button icon="el-icon-s-data" type="primary">显示</el-button>
            <el-button icon="el-icon-download" type="primary">导出</el-button>
          </div>
        </div>
      </el-card>

    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tableData: [{
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 1
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 2
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 3
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 4
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 5
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 6
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 7
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 8
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 9
      }, {
        "tc1": 2021,
        "tc2": 1,
        "tc3": 1,
        "tc4": 10
      }],
      form: {
        B0: "125.59",
        B1: "53.94",
        B2: "-52.23",
        B3: "0.06",
        B4: "-0.21",
        B5: "-33.38",
        B6: "-33.09",
        B7: "113.91",
        B8: "-113.92",
        B9: "66.29",
        B10: "-54.30",
        B11: "46.36",
        B12: "-2010.32",
        B13: "-2008.95",
        B14: "197.46",
        B15: "-197.46",
        B16: "4019.45",
        B17: "56.39",
        B18: "-90.57",
        B19: "32.59",
        B20: "2007.22",
        B21: "113.92",
        B22: "197.48",
        B23: "-3.39",
        MAPE: "4.1%",
        RMSE: "12.6%",
        F0: "125.59",
        F1: "53.94",
        F2: "-52.23",
        F3: "0.06",
        F4: "-0.21",
        F5: "-33.38",
        F6: "-33.09",
        F7: "113.91",
        F8: "-113.92",
        F9: "66.29",
        F10: "-54.30",
        F11: "46.36",
        F12: "-2010.32",
        F13: "-2008.95",
        F14: "197.46",
        F15: "-197.46",
        F16: "4019.45",
        F17: "56.39",
        MAPE2: "4.1%",
        RMSE2: "12%",
        J0: "125.59",
        J1: "53.94",
        J2: "-52.23",
        J3: "0.06",
        J4: "-0.21",
        J5: "-33.38",
        J6: "-33.09",
        J7: "113.91",
        J8: "-113.92",
        J9: "66.29",
        MAPE3: "4.1%",
        RMSE3: "12.6%",
        K0: "125.59",
        K1: "53.94",
        K2: "-52.23",
        K3: "0.06",
        K4: "-0.21",
        K5: "-33.38",
        K6: "-33.09",
        K7: "113.91",
        K8: "-113.92",
        K9: "66.29",
        K10: "-54.30",
        K11: "46.36",
        K12: "-2010.32",
        K13: "-2008.95",
        K14: "197.46",
        K15: "-197.46",
        K16: "4019.45",
        K17: "56.39",
        MAPE4: "4.1%",
        RMSE4: "12.6%",
        L0: "125.59",
        L1: "53.94",
        L2: "-52.23",
        L3: "0.06",
        L4: "-0.21",
        L5: "-33.38",
        L6: "-33.09",
        L7: "113.91",
        L8: "-113.92",
        L9: "66.29",
        MAPE5: "4.1%",
        RMSE5: "12.6%",
        A0: "125.59",
        A1: "53.94",
        A2: "-52.23",
        MAPE6: "4.1%",
        RMSE6: "12.6%",
        C0: "125.59",
        C1: "53.94",
        C2: "-52.23",
        MAPE7: "4.1%",
        RMSE7: "12.6%",
        D0: "125.59",
        D1: "53.94",
        D2: "-52.23",
        MAPE8: "4.1%",
        RMSE8: "12.6%",
        E0: "125.59",
        E1: "53.94",
        E2: "-52.23",
        E3: "53.94",
        MAPE9: "4.1%",
        RMSE9: "12.6%"
      },
      msg: "Welcome to Your Vue.js App",
      num1: 1,
      num2: 1,
      num3: 1,
      num4: 1
    };
  },
  mounted() {
    this.drawLine();
  },
  methods: {
    drawLine() {
      let frequencyChart = this.$echarts.init(document.getElementById("frequencyChart"));
      frequencyChart.setOption({
        tooltip: {},
        color: ["#37a2da", "#91cc75", "#fac858", "#ee6666", "#73c0de"],
        grid: {
          left: "5%",
          right: "3%",
          bottom: "3%",
          top: "15%",
          containLabel: true
        },
        xAxis: {
          type: "category",
          data: ["冷冻泵", "冷却泵"]
        },
        yAxis: {
          type: "value",
          min: 0,
          max: 50,
          name: "水泵频率Hz",
          position: "left",
          axisLabel: {
            formatter: "{value}"
          },
          splitLine: {
            show: false
          }
        },
        series: [
          {
            data: [50, 50],
            type: "bar",
            barWidth: 20,
            itemStyle: {
              color: "#9D9D9D"
            }
          },
          {
            data: [33, 43],
            type: "bar",
            barGap: "-100%",
            barWidth: 20
          }
        ]
      });

      var option2 = {
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow"
          },
          textStyle: {
            fontSize: 12
          }
        },
        color: ["#37a2da", "#91cc75", "#fac858", "#ee6666", "#73c0de"],
        legend: {
          data: ["主机", "冷冻泵", "冷却泵", "冷却塔"],
          orient: "horizontal",
          x: "right",
          y: "top",
          align: "left"
        },
        grid: {
          left: "1%",
          right: "1%",
          bottom: "1%",
          containLabel: true
        },
        xAxis: [
          {
            type: "category",
            data: ["1时", "2时", "3时", "4时", "5时", "6时", "7时"],
            name: "时间",
            nameLocation: "start"
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "功率Kw",
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            name: "主机",
            type: "bar",
            barWidth: 20,
            stack: "功率",
            data: [1393.59, 897.64, 1253.15, 986.32, 897.64, 615.65, 335.32]
          },
          {
            name: "冷冻泵",
            type: "bar",
            barWidth: 20,
            stack: "功率",
            data: [68.15, 80.15, 48.18, 50.30, 51.30, 30.30, 20.67]
          },
          {
            name: "冷却泵",
            type: "bar",
            barWidth: 20,
            stack: "功率",
            data: [68.15, 80.15, 48.18, 50.30, 51.30, 30.30, 20.67]
          },
          {
            name: "冷却塔",
            type: "bar",
            barWidth: 20,
            stack: "功率",
            data: [66.00, 66.00, 66.00, 44.45, 44.45, 30.30, 20.67]
          }
        ]
      };
      let chart2 = this.$echarts.init(document.getElementById("chart2"));
      chart2.setOption(option2);

      var option3 = {
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow"
          },
          textStyle: {
            fontSize: 12
          }
        },
        color: ["#37a2da", "#91cc75", "#fac858", "#ee6666", "#73c0de"],
        legend: {
          data: ["冷冻水泵", "冷却水泵"],
          orient: "horizontal",
          x: "right",
          y: "top",
          align: "left"
        },
        grid: {
          left: "3%",
          right: "3%",
          bottom: "3%",
          containLabel: true
        },
        xAxis: [
          {
            type: "category",
            data: ["1时", "2时", "3时", "4时", "5时", "6时", "7时"],
            name: "时间",
            nameLocation: "start"
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "流量m3/h",
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            name: "冷却水泵",
            type: "bar",
            barGap: 0,
            barWidth: 20,
            stack: "冷却",
            data: [650.00, 450.00, 550.00, 350.00, 650.87, 450.00, 550.00]
          },
          {
            name: "冷冻水泵",
            type: "bar",
            barWidth: 20,
            stack: "冷冻",
            data: [372.57, 362.57, 382.57, 272.57, 372.57, 252.57, 342.57]
          }
        ]
      };
      let chart3 = this.$echarts.init(document.getElementById("chart3"));
      chart3.setOption(option3);

      var option4 = {
        color: ["#37a2da", "#91cc75", "#fac858", "#ee6666", "#73c0de"],
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow"
          },
          textStyle: {
            fontSize: 12
          }
        },
        legend: {
          data: ["系统COP"],
          orient: "horizontal",
          x: "right",
          y: "top",
          align: "left"
        },
        grid: {
          left: "3%",
          right: "3%",
          bottom: "3%",
          containLabel: true
        },
        xAxis: [
          {
            type: "category",
            data: ["1时", "2时", "3时", "4时", "5时", "6时", "7时"],
            name: "时间",
            nameLocation: "start"
          }
        ],
        yAxis: [
          {
            type: "value",
            name: "系统COP",
            splitLine: {
              show: false
            }
          }
        ],
        series: [
          {
            name: "系统COP",
            type: "bar",
            barGap: 0,
            barWidth: 20,
            stack: "系统COP",
            data: [4.933, 5.933, 6.933, 5.933, 4.933, 5.933, 6.933]
          }
        ]
      };
      let chart4 = this.$echarts.init(document.getElementById("chart4"));
      chart4.setOption(option4);

      let t1Chart = this.$echarts.init(document.getElementById("t1Chart"));
      var optionT1 = {
        title: {
          show: true,
          text: "冷冻进/出水温度",
          left: "15%"
        },
        tooltip: {
          formatter: "{c}℃"
        },
        series: [
          {
            name: "冷冻进水温度",
            type: "gauge",
            axisLine: {
              lineStyle: {
                color: [[0.2, "#91c7ae"], [0.8, "#37a2da"], [1, "#c23531"]]
              }
            },
            pointer: {
              width: 4,
              length: "60%"
            },
            detail: {
              formatter: "进水{value}℃",
              fontSize: 15,
              offsetCenter: ["-60%", "95%"]
            },
            data: [{ value: 7, name: "" }],
            min: 0,
            max: 30,
            axisLabel: {
              show: true,
              formatter: "{value}",
              fontSize: 10
            }
          },
          {
            name: "冷冻出水温度",
            type: "gauge",
            axisLine: {
              lineStyle: {
                color: [[0.2, "#91c7ae"], [0.8, "#37a2da"], [1, "#c23531"]]
              }
            },
            pointer: {
              width: 4,
              length: "60%"
            },
            detail: {
              formatter: "出水{value}℃",
              fontSize: 15,
              offsetCenter: ["60%", "95%"]
            },
            data: [{ value: 18, name: "" }],
            min: 0,
            max: 30,
            axisLabel: {
              show: true,
              formatter: "{value}",
              fontSize: 10
            }
          }
        ]
      };
      t1Chart.setOption(optionT1);

      let t2Chart = this.$echarts.init(document.getElementById("t2Chart"));
      var optionT2 = {
        title: {
          show: true,
          text: "冷却进/出水温度",
          left: "15%"
        },
        tooltip: {
          formatter: "{c}℃"
        },
        series: [
          {
            name: "冷却进水温度",
            type: "gauge",
            axisLine: {
              lineStyle: {
                color: [[0.2, "#91c7ae"], [0.8, "#37a2da"], [1, "#c23531"]]
              }
            },
            pointer: {
              width: 4,
              length: "60%"
            },
            detail: {
              formatter: "进水{value}℃",
              fontSize: 15,
              offsetCenter: ["-60%", "95%"]
            },
            data: [{ value: 20, name: "" }],
            min: 10,
            max: 40,
            axisLabel: {
              show: true,
              formatter: "{value}",
              fontSize: 10
            }
          },
          {
            name: "冷却出水温度",
            type: "gauge",
            axisLine: {
              lineStyle: {
                color: [[0.2, "#91c7ae"], [0.8, "#37a2da"], [1, "#c23531"]]
              }
            },
            pointer: {
              width: 4,
              length: "60%"
            },
            detail: {
              formatter: "出水{value}℃",
              fontSize: 15,
              offsetCenter: ["60%", "95%"]
            },
            data: [{ value: 34, name: "" }],
            min: 10,
            max: 40,
            axisLabel: {
              show: true,
              formatter: "{value}",
              fontSize: 10
            }
          }
        ]
      };
      t2Chart.setOption(optionT2);

      let t3Chart = this.$echarts.init(document.getElementById("t3Chart"));
      var optionT3 = {
        title: {
          show: true,
          text: "干/湿球温度",
          left: "20%"
        },
        tooltip: {
          formatter: "{c}℃"
        },
        series: [
          {
            name: "干球温度",
            type: "gauge",
            axisLine: {
              lineStyle: {
                color: [[0.2, "#91c7ae"], [0.8, "#37a2da"], [1, "#c23531"]]
              }
            },
            pointer: {
              width: 4,
              length: "60%"
            },
            detail: {
              formatter: "干球{value}℃",
              fontSize: 15,
              offsetCenter: ["-60%", "95%"]
            },
            data: [{ value: 30, name: "" }],
            min: -5,
            max: 45,
            axisLabel: {
              show: true,
              formatter: "{value}",
              fontSize: 10
            }
          },
          {
            name: "湿球温度",
            type: "gauge",
            axisLine: {
              lineStyle: {
                color: [[0.2, "#91c7ae"], [0.8, "#37a2da"], [1, "#c23531"]]
              }
            },
            pointer: {
              width: 4,
              length: "60%"
            },
            detail: {
              formatter: "湿球{value}℃",
              fontSize: 15,
              offsetCenter: ["60%", "95%"]
            },
            data: [{ value: 15, name: "" }],
            min: -5,
            max: 45,
            axisLabel: {
              show: true,
              formatter: "{value}",
              fontSize: 10
            }
          }
        ]
      };
      t3Chart.setOption(optionT3);

      var optionPie = {
        title: {
          show: false,
          text: "功率",
          top: 0,
          right: 0
        },
        color: ["#37a2da", "#91cc75", "#fac858", "#ee6666", "#73c0de"],
        tooltip: {
          trigger: "item",
          formatter: "{a} <br/>{b} : {c} ({d}%)"
        },
        grid: {
          left: "1%",
          right: "1%",
          bottom: "1%",
          containLabel: true
        },
        series: [
          {
            name: "功率",
            type: "pie",
            radius: "75%",
            center: ["50%", "40%"],
            labelLine: {
              show: false
            },
            label: {
              show: false,
              position: "center"
            },
            data: [
              { value: 1393.59, name: "主机" },
              { value: 68.15, name: "冷冻泵" },
              { value: 68.15, name: "冷却泵" },
              { value: 68.15, name: "冷却塔" }
            ]
          }
        ]
      };
      let pieChart = this.$echarts.init(document.getElementById("pieChart"));
      pieChart.setOption(optionPie);
    }
  }
};
</script>

<style lang="scss">
  .app-main {
    background: #31629f;
  }

  .dashboard .el-table .cell{
    padding-left:1px;
    padding-right:1px;
  }
  .dashboard .el-table th > .cell{
    padding-left:1px;
    padding-right:1px;
    font-weight:600;
    font-size:8px;
  }
  .dashboard .el-table .el-table__header-wrapper th, .el-table .el-table__fixed-header-wrapper th{
      background: #31629f;
      color: black;
  }
  .dashboard .el-table--mini{
    font-size:8px;
  }
  .dashboard .el-table th>.cell{
    white-space: pre-wrap;
    line-height: 15px;
  }

  .dashboard .el-card__header{
      background: #304156;
   }

  .dashboard .el-card {
      border-radius: 10px;
   }

  .dashboard .out {
    color: #13ce66;
    white-space:nowrap;
    text-overflow:ellipsis;
    overflow:hidden;
    text-align:right;
  }

  .dashboard .self-row-1 {
    font-size: 14px;
    margin: 8px;
  }

  .dashboard .first-batch {
    background: #84C1FF;
  }

  .dashboard .el-card__body {
    padding-top: 5px;
  }

</style>
