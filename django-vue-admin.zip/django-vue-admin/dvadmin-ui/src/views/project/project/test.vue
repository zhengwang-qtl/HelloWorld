<template style="background: blue">
  <div>
    <el-dialog :title="importTitle" :visible.sync="importOpen" width="400px" append-to-body @close="submitFileForm">
      <Import ref="importFile" :funcs="funcs" @input="submitFileForm">
      </Import>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitFileForm">确 定</el-button>
        <el-button @click="importOpen = false">取 消</el-button>
      </div>
    </el-dialog>
    <el-button type="primary" icon="el-icon-setting" @click="handleImport">setting</el-button>
  </div>
</template>

<script>
import Import from "@/components/Import/index";
import * as Project from "../../../api/project/project";

export default {
  components: { Import },
  data() {
    return {
      importOpen: false,
      importTitle: "导入",
      funcs: [
        { type: "import", label: "导入", api: Project.importsProject, template_api: Project.importTemplate }
      ]
    };
  },
  methods: {
    /** 完成按钮 */
    submitFileForm: function() {
      this.importOpen = false;
      this.$refs.importFile.fileList = [];
      this.$refs.importFile.submitFileForm();
    },
    /** 导入按钮操作 */
    handleImport() {
      this.importTitle = "导入";
      this.importOpen = true;
    }
  }
};
</script>

<style lang="scss">

</style>
