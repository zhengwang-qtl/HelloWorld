import django_filters

from .models import Project, InitParam, AircooledHeatpumpUnit, ChilledWaterPump, CoolingTower, CoolingWaterPump, \
    EvaporativeCoolingMachine, HostDevice, LoadDrywetbulbtemperature


class ProjectFilter(django_filters.rest_framework.FilterSet):
    """
    项目管理 简单序过滤器
    """
    # 通过 lookup_expr 可进行模糊查询，其他配置可自行百度
    name = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Project
        exclude = ('description', 'creator', 'modifier')


class InitParamFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """
    # 通过 lookup_expr 可进行模糊查询，其他配置可自行百度
    name = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = InitParam
        exclude = ('description', 'creator', 'modifier')


class AircooledHeatpumpUnitFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """

    class Meta:
        model = AircooledHeatpumpUnit
        exclude = ('description', 'creator', 'modifier')


class ChilledWaterPumpFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """

    class Meta:
        model = ChilledWaterPump
        exclude = ('description', 'creator', 'modifier')


class CoolingTowerFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """

    class Meta:
        model = CoolingTower
        exclude = ('description', 'creator', 'modifier')


class CoolingWaterPumpFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """

    class Meta:
        model = CoolingWaterPump
        exclude = ('description', 'creator', 'modifier')


class EvaporativeCoolingMachineFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """

    class Meta:
        model = EvaporativeCoolingMachine
        exclude = ('description', 'creator', 'modifier')


class HostDeviceFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """

    class Meta:
        model = HostDevice
        exclude = ('description', 'creator', 'modifier')


class LoadDrywetbulbtemperatureFilter(django_filters.rest_framework.FilterSet):
    """
    初始化参数 简单序过滤器
    """

    class Meta:
        model = LoadDrywetbulbtemperature
        exclude = ('description', 'creator', 'modifier')
