from django.urls import re_path
from rest_framework.routers import DefaultRouter

from apps.project.views import ProjectModelViewSet, InitParamModelViewSet, AircooledHeatpumpUnitModelViewSet, ChilledWaterPumpModelViewSet, CoolingTowerModelViewSet, CoolingWaterPumpModelViewSet,  EvaporativeCoolingMachineModelViewSet,  HostDeviceModelViewSet, LoadDrywetbulbtemperatureModelViewSet

router = DefaultRouter()
router.register(r'project', ProjectModelViewSet)
router.register(r'InitParam', InitParamModelViewSet)
router.register(r'AircooledHeatpumpUnit', AircooledHeatpumpUnitModelViewSet)
router.register(r'ChilledWaterPump', ChilledWaterPumpModelViewSet)
router.register(r'CoolingTower', CoolingTowerModelViewSet)
router.register(r'CoolingWaterPump', CoolingWaterPumpModelViewSet)
router.register(r'EvaporativeCoolingMachine', EvaporativeCoolingMachineModelViewSet)
router.register(r'HostDevice', HostDeviceModelViewSet)
router.register(r'LoadDrywetbulbtemperature', LoadDrywetbulbtemperatureModelViewSet)

urlpatterns = [
    # 导出
    re_path('project/export/', ProjectModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('project/importTemplate/',
            ProjectModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    # 导出
    re_path('AircooledHeatpumpUnit/export/', AircooledHeatpumpUnitModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('AircooledHeatpumpUnit/importTemplate/',
            AircooledHeatpumpUnitModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    # 清理
    re_path('AircooledHeatpumpUnit/clean/', AircooledHeatpumpUnitModelViewSet.as_view({'get': 'clean_all'})),

    # 导出
    re_path('ChilledWaterPump/export/', ChilledWaterPumpModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('ChilledWaterPump/importTemplate/',
            ChilledWaterPumpModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    # 清理
    re_path('ChilledWaterPump/clean/', ChilledWaterPumpModelViewSet.as_view({'get': 'clean_all'})),

    # 导出
    re_path('CoolingTower/export/', CoolingTowerModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('CoolingTower/importTemplate/',
            CoolingTowerModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    re_path('CoolingTower/clean/', CoolingTowerModelViewSet.as_view({'get': 'clean_all'})),

    # 导出
    re_path('CoolingWaterPump/export/', CoolingWaterPumpModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('CoolingWaterPump/importTemplate/',
            CoolingWaterPumpModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    # 清理
    re_path('CoolingWaterPump/clean/', CoolingTowerModelViewSet.as_view({'get': 'clean_all'})),

    # 导出
    re_path('EvaporativeCoolingMachine/export/', EvaporativeCoolingMachineModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('EvaporativeCoolingMachine/importTemplate/',
            EvaporativeCoolingMachineModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    # 清理
    re_path('EvaporativeCoolingMachine/clean/', EvaporativeCoolingMachineModelViewSet.as_view({'get': 'clean_all'})),

    # 导出
    re_path('HostDevice/export/', HostDeviceModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('HostDevice/importTemplate/',
            HostDeviceModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    # 清理
    re_path('HostDevice/clean/', HostDeviceModelViewSet.as_view({'get': 'clean_all'})),

    # 导出
    re_path('LoadDrywetbulbtemperature/export/', LoadDrywetbulbtemperatureModelViewSet.as_view({'get': 'export', })),
    # 导入模板下载及导入
    re_path('LoadDrywetbulbtemperature/importTemplate/',
            LoadDrywetbulbtemperatureModelViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
    # 清理
    re_path('LoadDrywetbulbtemperature/clean/', LoadDrywetbulbtemperatureModelViewSet.as_view({'get': 'clean_all'})),
]

urlpatterns += router.urls