from .models import Project, InitParam, AircooledHeatpumpUnit, ChilledWaterPump, CoolingTower, CoolingWaterPump, \
    EvaporativeCoolingMachine, HostDevice, LoadDrywetbulbtemperature
from apps.project.filters import ProjectFilter, InitParamFilter, AircooledHeatpumpUnitFilter, ChilledWaterPumpFilter, \
    CoolingTowerFilter, CoolingWaterPumpFilter, EvaporativeCoolingMachineFilter, HostDeviceFilter, \
    LoadDrywetbulbtemperatureFilter
from apps.project.serializers import ProjectSerializer, ExportProjectSerializer, InitParamSerializer, \
    AircooledHeatpumpUnitSerializer, ChilledWaterPumpSerializer, CoolingTowerSerializer, CoolingWaterPumpSerializer, \
    EvaporativeCoolingMachineSerializer, HostDeviceSerializer, LoadDrywetbulbtemperatureSerializer
from apps.project.serializers import ProjectCreateUpdateSerializer, InitParamCreateUpdateSerializer, \
    AircooledHeatpumpUnitCreateUpdateSerializer, ChilledWaterPumpCreateUpdateSerializer, \
    CoolingTowerCreateUpdateSerializer, CoolingWaterPumpCreateUpdateSerializer, \
    EvaporativeCoolingMachineCreateUpdateSerializer, HostDeviceCreateUpdateSerializer, \
    LoadDrywetbulbtemperatureCreateUpdateSerializer
from apps.vadmin.op_drf.filters import DataLevelPermissionsFilter
from apps.vadmin.op_drf.viewsets import CustomModelViewSet
from apps.vadmin.permission.permissions import CommonPermission
from rest_framework.request import Request
from apps.vadmin.op_drf.response import SuccessResponse, ErrorResponse


class ProjectModelViewSet(CustomModelViewSet):
    """
    项目管理 的CRUD视图
    """
    queryset = Project.objects.all()
    serializer_class = ProjectSerializer  # 序列化器
    create_serializer_class = ProjectCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = ProjectCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = ProjectFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    search_fields = ('name',)  # 搜索
    ordering = ['create_datetime']  # 默认排序
    # 导出
    export_field_data = ['项目序号', '项目名称', '项目编码', '项目负责人', '项目所属部门', '创建者', '修改者', '备注']  # 导出
    export_serializer_class = ExportProjectSerializer  # 导出序列化器
    # 导入
    import_field_data = {'name': '项目名称', 'code': '项目编码', 'person': '项目负责人ID', 'dept': '部门ID'}
    import_serializer_class = ExportProjectSerializer


class InitParamModelViewSet(CustomModelViewSet):
    """
    初始化参数 的CRUD视图
    """
    queryset = InitParam.objects.all()
    serializer_class = InitParamSerializer  # 序列化器
    create_serializer_class = InitParamCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = InitParamCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = InitParamFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")


class AircooledHeatpumpUnitModelViewSet(CustomModelViewSet):
    queryset = AircooledHeatpumpUnit.objects.all()
    serializer_class = AircooledHeatpumpUnitSerializer  # 序列化器
    create_serializer_class = AircooledHeatpumpUnitCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = AircooledHeatpumpUnitCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = AircooledHeatpumpUnitFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    # 导入
    import_field_data = {'load_percentage': '负荷百分比', 'cooling_capacity': '制冷量', 'power_percentage': '功率百分比',
                         'input_power': '输入功率', 'outlet_temperature': '出水温度', 'inlet_temperature': '进水温度',
                         'outdoor_dry_bulb_temperature': '室外干球温度', 'cop': 'COP'}
    import_serializer_class = AircooledHeatpumpUnitSerializer

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")


class ChilledWaterPumpModelViewSet(CustomModelViewSet):
    queryset = ChilledWaterPump.objects.all()
    serializer_class = ChilledWaterPumpSerializer  # 序列化器
    create_serializer_class = ChilledWaterPumpCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = ChilledWaterPumpCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = ChilledWaterPumpFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    # 导入
    import_field_data = {'key': 'key', 'value': 'value'}
    import_serializer_class = ChilledWaterPumpSerializer

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")


class CoolingTowerModelViewSet(CustomModelViewSet):
    queryset = CoolingTower.objects.all()
    serializer_class = CoolingTowerSerializer  # 序列化器
    create_serializer_class = CoolingTowerCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = CoolingTowerCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = CoolingTowerFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    # 导入
    import_field_data = {'wet_bulb_temperature': '湿球温度', 'cold_width': '冷幅', 'inlet_water_temperature': '进水温度',
                         'outlet_water_temperature': '出水温度', 'water_flow': '水流量', 'air_flow': '空气流量',
                         'fan_power': '风机功率'}
    import_serializer_class = CoolingTowerCreateUpdateSerializer

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")


class CoolingWaterPumpModelViewSet(CustomModelViewSet):
    queryset = CoolingWaterPump.objects.all()
    serializer_class = CoolingWaterPumpSerializer  # 序列化器
    create_serializer_class = CoolingWaterPumpCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = CoolingWaterPumpCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = CoolingWaterPumpFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    # 导入
    import_field_data = {'key': 'key', 'value': 'value'}
    import_serializer_class = CoolingWaterPumpSerializer

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")


class EvaporativeCoolingMachineModelViewSet(CustomModelViewSet):
    queryset = EvaporativeCoolingMachine.objects.all()
    serializer_class = EvaporativeCoolingMachineSerializer  # 序列化器
    create_serializer_class = EvaporativeCoolingMachineCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = EvaporativeCoolingMachineCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = EvaporativeCoolingMachineFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    # 导入
    import_field_data = {'load_percentage': '负荷百分比', 'cooling_capacity': '制冷量', 'power_percentage': '功率百分比',
                         'input_power': '输入功率', 'outlet_temperature': '出水温度', 'inlet_temperature': '进水温度',
                         'outdoor_wet_bulb_temperature': '室外湿球温度', 'cop': 'COP'}

    import_serializer_class = EvaporativeCoolingMachineSerializer

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")


class HostDeviceModelViewSet(CustomModelViewSet):
    queryset = HostDevice.objects.all()
    serializer_class = HostDeviceSerializer  # 序列化器
    create_serializer_class = HostDeviceCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = HostDeviceCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = HostDeviceFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    # 导入
    import_field_data = {'load_percentage': '负荷百分比', 'cooling_capacity': '制冷量',
                         'power_percentage': '功率百分比', 'input_power': '输入功率',
                         'chilled_water_outlet_temperature': '冷冻水出水温度', 'chilled_water_inlet_temperature': '冷冻水进水温度',
                         'cooling_water_outlet_temperature': '冷却水出水温度', 'cooling_water_inlet_temperature': '冷却水进水温度',
                         'cop': 'COP'}
    import_serializer_class = HostDeviceCreateUpdateSerializer

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")


class LoadDrywetbulbtemperatureModelViewSet(CustomModelViewSet):
    queryset = LoadDrywetbulbtemperature.objects.all()
    serializer_class = LoadDrywetbulbtemperatureSerializer  # 序列化器
    create_serializer_class = LoadDrywetbulbtemperatureCreateUpdateSerializer  # 创建/更新时的列化器
    update_serializer_class = LoadDrywetbulbtemperatureCreateUpdateSerializer  # 创建/更新时的列化器
    filter_class = LoadDrywetbulbtemperatureFilter  # 过滤器
    extra_filter_backends = [DataLevelPermissionsFilter]  # 数据权限类，不需要可注释掉
    update_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    destroy_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    create_extra_permission_classes = (CommonPermission,)  # 判断用户是否有这条数据的权限
    # 导入
    import_field_data = {'year': '年', 'month': '月', 'day': '日', 'time': '时', 'load': '负荷',
                         'outdoor_dry_bulb_temperature': '室外湿球温度', 'outdoor_wet_bulb_temperature': '室外干球温度'}
    import_serializer_class = LoadDrywetbulbtemperatureSerializer

    def clean_all(self, request: Request, *args, **kwargs):
        """
        清空
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        self.get_queryset().delete()
        return SuccessResponse(msg="清空成功")
