from rest_framework import serializers

from .models import Project, InitParam, AircooledHeatpumpUnit, ChilledWaterPump, CoolingTower, CoolingWaterPump, \
    EvaporativeCoolingMachine, HostDevice, LoadDrywetbulbtemperature

from vadmin.op_drf.serializers import CustomModelSerializer


# ================================================= #
# ************** 项目管理 序列化器  ************** #
# ================================================= #
class ProjectSerializer(CustomModelSerializer):
    """
    项目管理 简单序列化器
    """

    class Meta:
        model = Project
        fields = '__all__'


class ProjectCreateUpdateSerializer(CustomModelSerializer):
    """
    项目管理 创建/更新时的列化器
    """

    # 此处可写定制的 创建/更新 内容
    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = Project
        fields = '__all__'


class ExportProjectSerializer(CustomModelSerializer):
    """
    导出 项目管理 简单序列化器
    """
    person__username = serializers.SerializerMethodField(read_only=False)
    dept__deptName = serializers.SerializerMethodField(read_only=False)

    def get_person__username(self, obj):
        return "" if not hasattr(obj, 'person') else obj.person.username

    def get_dept__deptName(self, obj):
        return "" if not hasattr(obj, 'dept') else obj.dept.deptName

    class Meta:
        model = Project
        fields = ('id', 'name', 'code', 'person', 'person__username', 'dept', 'dept__deptName', 'creator', 'modifier',
                  'description')


# ================================================= #
# ************** 初始化参数 序列化器  ************** #
# ================================================= #
class InitParamSerializer(CustomModelSerializer):
    """
    初始化参数 简单序列化器
    """

    class Meta:
        model = InitParam
        fields = '__all__'


class InitParamCreateUpdateSerializer(CustomModelSerializer):
    """
    初始化参数 创建/更新时的列化器
    """

    # 此处可写定制的 创建/更新 内容
    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = InitParam
        fields = '__all__'


class AircooledHeatpumpUnitSerializer(CustomModelSerializer):
    class Meta:
        model = AircooledHeatpumpUnit
        fields = '__all__'


class AircooledHeatpumpUnitCreateUpdateSerializer(CustomModelSerializer):

    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = AircooledHeatpumpUnit
        fields = '__all__'


class ChilledWaterPumpSerializer(CustomModelSerializer):
    class Meta:
        model = ChilledWaterPump
        fields = '__all__'


class ChilledWaterPumpCreateUpdateSerializer(CustomModelSerializer):

    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = ChilledWaterPump
        fields = '__all__'


class CoolingTowerSerializer(CustomModelSerializer):
    class Meta:
        model = CoolingTower
        fields = '__all__'


class CoolingTowerCreateUpdateSerializer(CustomModelSerializer):

    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = CoolingTower
        fields = '__all__'


class CoolingWaterPumpSerializer(CustomModelSerializer):
    class Meta:
        model = CoolingWaterPump
        fields = '__all__'


class CoolingWaterPumpCreateUpdateSerializer(CustomModelSerializer):

    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = CoolingWaterPump
        fields = '__all__'


class EvaporativeCoolingMachineSerializer(CustomModelSerializer):
    class Meta:
        model = EvaporativeCoolingMachine
        fields = '__all__'


class EvaporativeCoolingMachineCreateUpdateSerializer(CustomModelSerializer):

    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = EvaporativeCoolingMachine
        fields = '__all__'


class HostDeviceSerializer(CustomModelSerializer):
    class Meta:
        model = HostDevice
        fields = '__all__'


class HostDeviceCreateUpdateSerializer(CustomModelSerializer):

    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = HostDevice
        fields = '__all__'


class LoadDrywetbulbtemperatureSerializer(CustomModelSerializer):
    class Meta:
        model = LoadDrywetbulbtemperature
        fields = '__all__'


class LoadDrywetbulbtemperatureCreateUpdateSerializer(CustomModelSerializer):

    def validate(self, attrs: dict):
        return super().validate(attrs)

    class Meta:
        model = LoadDrywetbulbtemperature
        fields = '__all__'
