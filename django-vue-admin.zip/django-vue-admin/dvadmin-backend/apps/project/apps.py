from django.apps import AppConfig


class TConfig(AppConfig):
    name = 'apps.project'
    verbose_name = "projectApp"
