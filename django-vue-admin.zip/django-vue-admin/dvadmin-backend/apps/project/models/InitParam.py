from django.conf import settings
from django.db.models import CharField, ForeignKey, CASCADE, SET_NULL

from vadmin.op_drf.models import BaseModel


# 继承框架封装的 模型类 BaseModel
class InitParam(BaseModel):
    key = CharField(max_length=63, verbose_name='key')
    value = CharField(max_length=1023, verbose_name='value')

    class Meta:
        verbose_name = '初始化参数'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.key} 值"
