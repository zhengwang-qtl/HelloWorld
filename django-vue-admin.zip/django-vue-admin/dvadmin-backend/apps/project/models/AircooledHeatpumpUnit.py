from django.conf import settings
from django.db.models import FloatField

from vadmin.op_drf.models import BaseModel


# 继承框架封装的 模型类 BaseModel
class AircooledHeatpumpUnit(BaseModel):
    load_percentage = FloatField(verbose_name='load_percentage', null=True)
    cooling_capacity = FloatField(verbose_name='cooling_capacity', null=True)
    power_percentage = FloatField(verbose_name='power_percentage', null=True)
    input_power = FloatField(verbose_name='input_power', null=True)
    outlet_temperature = FloatField(verbose_name='outlet_temperature', null=True)
    inlet_temperature = FloatField(verbose_name='inlet_temperature', null=True)
    outdoor_dry_bulb_temperature = FloatField(verbose_name='outdoor_dry_bulb_temperature', null=True)
    cop = FloatField(verbose_name='cop', null=True)

    class Meta:
        verbose_name = '风冷热泵机组'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.cop}"
