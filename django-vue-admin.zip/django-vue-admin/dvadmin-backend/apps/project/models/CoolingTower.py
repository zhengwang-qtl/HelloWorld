from django.conf import settings
from django.db.models import FloatField

from vadmin.op_drf.models import BaseModel


# 继承框架封装的 模型类 BaseModel
class CoolingTower(BaseModel):
    wet_bulb_temperature = FloatField (verbose_name='wet_bulb_temperature', null=True)
    cold_width = FloatField(verbose_name='cold_width', null=True)
    inlet_water_temperature = FloatField(verbose_name='inlet_water_temperature', null=True)
    outlet_water_temperature = FloatField(verbose_name='outlet_water_temperature', null=True)
    water_flow = FloatField(verbose_name='water_flow', null=True)
    air_flow = FloatField(verbose_name='air_flow', null=True)
    fan_power = FloatField(verbose_name='fan_power', null=True)

    class Meta:
        verbose_name = '冷却塔'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.wet_bulb_temperature}"
