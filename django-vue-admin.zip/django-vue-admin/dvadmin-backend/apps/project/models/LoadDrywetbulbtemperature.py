from django.conf import settings
from django.db.models import IntegerField, FloatField

from vadmin.op_drf.models import BaseModel


# 继承框架封装的 模型类 BaseModel
class LoadDrywetbulbtemperature(BaseModel):
    year = IntegerField(verbose_name='year', null=True)
    month = IntegerField(verbose_name='month', null=True)
    day = IntegerField(verbose_name='day', null=True)
    time = IntegerField(verbose_name='time', null=True)
    load = FloatField (verbose_name='load', null=True)
    outdoor_dry_bulb_temperature = FloatField(verbose_name='outdoor_dry_bulb_temperature', null=True)
    outdoor_wet_bulb_temperature = FloatField(verbose_name='outdoor_wet_bulb_temperature', null=True)

    class Meta:
        verbose_name = '负荷、室外干球温度、室外干球温度'
        verbose_name_plural = verbose_name
