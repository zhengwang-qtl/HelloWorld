from django.conf import settings
from django.db.models import CharField, FloatField

from vadmin.op_drf.models import BaseModel


# 继承框架封装的 模型类 BaseModel
class HostDevice(BaseModel):
    host_device_name = CharField(max_length=63, verbose_name='host_device_name', null=True)
    load_percentage = FloatField (verbose_name='load_percentage', null=True)
    cooling_capacity = FloatField(verbose_name='cooling_capacity', null=True)
    power_percentage = FloatField(verbose_name='power_percentage', null=True)
    input_power = FloatField(verbose_name='input_power', null=True)
    chilled_water_outlet_temperature = FloatField(verbose_name='chilled_water_outlet_temperature', null=True)
    chilled_water_inlet_temperature = FloatField(verbose_name='chilled_water_inlet_temperature', null=True)
    cooling_water_outlet_temperature = FloatField(verbose_name='cooling_water_outlet_temperature', null=True)
    cooling_water_inlet_temperature = FloatField(verbose_name='cooling_water_inlet_temperature', null=True)
    cop = FloatField(verbose_name='cop', null=True)

    class Meta:
        verbose_name = '主机设备'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.host_device_name} 值"
