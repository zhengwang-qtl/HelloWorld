from django.apps import AppConfig


class SystemConfig(AppConfig):
    name = 'apps.vadmin.system'
    verbose_name = "系统管理"
