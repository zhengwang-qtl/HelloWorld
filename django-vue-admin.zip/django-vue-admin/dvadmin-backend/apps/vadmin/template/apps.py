from django.apps import AppConfig


class TemplateConfig(AppConfig):
    name = 'apps.vadmin.template'
    verbose_name = "模板App"
