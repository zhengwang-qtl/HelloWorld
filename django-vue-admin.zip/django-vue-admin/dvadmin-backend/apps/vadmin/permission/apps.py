from django.apps import AppConfig


class PermissionConfig(AppConfig):
    name = 'apps.vadmin.permission'
    verbose_name = "权限管理"
