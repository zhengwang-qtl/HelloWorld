from apps.vadmin.permission.models.dept import Dept
from apps.vadmin.permission.models.menu import Menu
from apps.vadmin.permission.models.post import Post
from apps.vadmin.permission.models.role import Role
from apps.vadmin.permission.models.users import UserProfile
