from django.apps import AppConfig


class MonitorConfig(AppConfig):
    name = 'apps.vadmin.monitor'
    verbose_name = "系统监控"
