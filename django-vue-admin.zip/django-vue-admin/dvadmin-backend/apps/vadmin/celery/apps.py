from django.apps import AppConfig


class DpCmdbConfig(AppConfig):
    name = 'apps.vadmin.celery'


