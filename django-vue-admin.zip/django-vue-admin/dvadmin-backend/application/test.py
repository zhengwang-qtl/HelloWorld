import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

print(BASE_DIR)
print(BASE_DIR.replace('\\', os.sep))
file_url="/media/system/2022-04-17/1d51b302-b8df-4f44-93f2-957ed0d9149a.xlsx"
print(file_url.split(os.sep))
print(*file_url.split(os.sep))
file_url=file_url.replace('/', os.sep)
print(os.path.join(BASE_DIR.replace('\\', os.sep), *file_url.split(os.sep)))
####问题 为何要有split