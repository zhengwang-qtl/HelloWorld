cd ../../dvadmin-backend/

docker build -f docker_env/django/Dockerfile -t django:2.2 .
