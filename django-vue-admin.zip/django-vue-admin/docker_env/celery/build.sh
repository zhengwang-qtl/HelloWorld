cd ../../backend/
docker build -f docker_env/celery/Dockerfile -t celery:1.0 .
